<?php
// ⚠️ Este archivo NUNCA se sube a GitHub (.gitignore)
putenv('GOOGLE_CLIENT_ID=1092083145876-8ubhh9ol0ft0bk0rc0514fpjlm7727ib.apps.googleusercontent.com');
putenv('GOOGLE_CLIENT_SECRET=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');
putenv('APP_URL=http://localhost/BiconoirsGourmet/public');