<?php
// ⚠️ Este archivo NUNCA se sube a GitHub (.gitignore)
// Configura aquí tus credenciales locales de desarrollo

putenv('GOOGLE_CLIENT_ID=TU_GOOGLE_CLIENT_ID_AQUI');
putenv('GOOGLE_CLIENT_SECRET=TU_GOOGLE_CLIENT_SECRET_AQUI');
putenv('APP_URL=http://localhost/OAuth_Biconoir_Simple/public');
