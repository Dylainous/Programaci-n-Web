-- ============================================================================
-- Biconoirs Template - Schema SQL para Supabase (Postgres)
-- Requisito 6: Script SQL para base de datos (plantilla)
-- ============================================================================
-- Cómo usarlo:
-- 1. Crea un proyecto en https://supabase.com
-- 2. Ve a "SQL Editor" -> "New query"
-- 3. Pega este archivo completo y ejecútalo (Run)
-- 4. Copia el "Connection string" (Project Settings > Database) hacia el
--    DATABASE_URL de AMBOS backends (usa el modo "Transaction pooler", puerto 6543)
-- ============================================================================

-- Extensión necesaria para generar UUIDs
create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------------
-- USERS: usuarios de la plataforma (usado por el backend Class Operations)
-- ---------------------------------------------------------------------------
create table if not exists users (
  id            uuid primary key default gen_random_uuid(),
  full_name     text not null,
  email         text not null unique,
  password_hash text not null,
  role          text not null default 'customer' check (role in ('customer', 'admin')),
  created_at    timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- PRODUCTS: catálogo (entidad de "clase" -> operaciones CRUD)
-- ---------------------------------------------------------------------------
create table if not exists products (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  description text,
  price       numeric(10, 2) not null check (price >= 0),
  stock       integer not null default 0 check (stock >= 0),
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------------
-- CART_ITEMS: origen de verdad del carrito (respaldado por caché en Redis,
-- ver requisito 8 en backend-class-operations/src/controllers/cart.controller.js)
-- ---------------------------------------------------------------------------
create table if not exists cart_items (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references users(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  quantity   integer not null check (quantity > 0),
  updated_at timestamptz not null default now(),
  unique (user_id, product_id)
);

-- ---------------------------------------------------------------------------
-- ORDERS / ORDER_ITEMS: generadas por el backend Business Logic al hacer checkout
-- ---------------------------------------------------------------------------
create table if not exists orders (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references users(id) on delete cascade,
  status     text not null default 'pending' check (status in ('pending', 'paid', 'shipped', 'cancelled')),
  total      numeric(10, 2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists order_items (
  id         uuid primary key default gen_random_uuid(),
  order_id   uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id),
  quantity   integer not null check (quantity > 0),
  unit_price numeric(10, 2) not null
);

-- ---------------------------------------------------------------------------
-- Índices para las consultas más frecuentes
-- ---------------------------------------------------------------------------
create index if not exists idx_cart_items_user on cart_items(user_id);
create index if not exists idx_orders_user on orders(user_id);
create index if not exists idx_order_items_order on order_items(order_id);

-- ---------------------------------------------------------------------------
-- Datos semilla para poder probar la plantilla de inmediato
-- ---------------------------------------------------------------------------
insert into products (name, description, price, stock) values
  ('Teclado mecánico', 'Teclado mecánico RGB switches rojos', 45.99, 50),
  ('Mouse inalámbrico', 'Mouse ergonómico 2.4GHz', 19.99, 100),
  ('Monitor 24"', 'Monitor Full HD IPS 75Hz', 129.99, 20),
  ('Audífonos USB', 'Audífonos con micrófono para videollamadas', 24.50, 80)
on conflict do nothing;
