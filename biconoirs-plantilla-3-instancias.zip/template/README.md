# Biconoirs — Plantilla de trabajo (3 instancias AWS)

Plantilla de arquitectura de 3 partes conectadas, pensada para desplegarse
cada una en su propia instancia de AWS:

1. **`frontend/`** — React + Vite. Consume ambos backends por HTTPS.
2. **`backend-class-operations/`** — Node.js + Express. CRUD de entidades
   (usuarios, productos, carrito). Puerto `4001`.
3. **`backend-business-logic/`** — Node.js + Express. Reglas de negocio
   (checkout, órdenes). Llama al backend anterior por HTTP. Puerto `4002`.

Todo el backend está en **JavaScript puro** (sin TypeScript), usando
`require`/`module.exports` (CommonJS) para que sea fácil de leer y de
depurar en clase.

## Dónde está cada requisito

| # | Requisito | Dónde |
|---|---|---|
| 6 | Script SQL de base de datos (Supabase) | `database/schema.sql` |
| 7 | Ejemplo de método asíncrono | `backend-class-operations/src/controllers/auth.controller.js` (signup/login) y `backend-business-logic/src/controllers/checkout.controller.js` (combina fetch + queries con async/await) |
| 8 | Caché (carrito visible entre pestañas) | `backend-class-operations/src/cache/redisClient.js` + `src/controllers/cart.controller.js` |
| 9 | HTTPS con AWS + DuckDNS (guía completa) | `docs/https-duckdns-aws-guide.md` + `*/deploy/setup-ec2.sh` en cada proyecto |
| 10 | Sesión de usuario con token | `backend-class-operations/src/middleware/auth.middleware.js` (JWT), emitido en `auth.controller.js` |
| 12 | Proceso bloqueante | `backend-class-operations/src/examples/blocking.example.js` (`GET /examples/blocking`) |
| 13 | Proceso no bloqueante | `backend-class-operations/src/examples/nonBlocking.example.js` (`GET /examples/non-blocking`) |

## Cómo correrlo en local (antes de desplegar)

### 1. Base de datos (Supabase)

1. Crea un proyecto gratis en [supabase.com](https://supabase.com)
2. Abre el **SQL Editor** y pega el contenido de `database/schema.sql` → Run
3. Copia el **Connection string** (modo *Transaction pooler*, puerto `6543`)

### 2. Redis (cache)

Crea una base gratuita en [Redis Cloud](https://redis.io/try-free/) y
copia su URL de conexión (`redis://default:password@host:puerto`).

### 3. Backend Class Operations

```bash
cd backend-class-operations
cp .env.example .env     # completa DATABASE_URL, REDIS_URL, JWT_SECRET
npm install
npm run dev               # http://localhost:4001
```

### 4. Backend Business Logic

```bash
cd backend-business-logic
cp .env.example .env     # completa DATABASE_URL, CLASS_OPS_URL=http://localhost:4001, mismo JWT_SECRET
npm install
npm run dev               # http://localhost:4002
```

> Requiere Node.js 18+ (usa `fetch` nativo para llamar al otro backend).

### 5. Frontend

```bash
cd frontend
cp .env.example .env     # VITE_CLASS_OPS_URL y VITE_BUSINESS_LOGIC_URL apuntando a localhost
npm install
npm run dev                # http://localhost:5173
```

## Cómo probar cada requisito

- **Caché del carrito (8):** inicia sesión, agrega productos al carrito,
  luego abre la misma URL en otra pestaña (o refresca) — el carrito ya
  está ahí porque se lee de Redis, no de `localStorage`. El panel de
  "Carrito" en el frontend muestra si el dato vino de `cache` o de `database`.
- **Bloqueante vs no bloqueante (12/13):** en el frontend, panel
  "Blocking vs Non-blocking", corre ambas pruebas y observa el log de
  pings a `/health` — durante el proceso bloqueante los pings se
  retrasan; durante el no bloqueante siguen respondiendo con normalidad.
- **Sesión con token (10):** revisa el header `Authorization: Bearer ...`
  en las peticiones del navegador (DevTools → Network) después de hacer login.
- **Async (7):** lee los comentarios en `auth.controller.js` y
  `checkout.controller.js`.

## Despliegue a producción (AWS + DuckDNS + HTTPS)

Sigue la guía completa en [`docs/https-duckdns-aws-guide.md`](docs/https-duckdns-aws-guide.md).
Resumen: 3 instancias EC2 (una por parte) → Elastic IP en cada una → 3
subdominios DuckDNS apuntando a cada Elastic IP → correr
`deploy/setup-ec2.sh <tu-subdominio.duckdns.org>` dentro de cada instancia
(instala nginx + Certbot + PM2 y emite el certificado TLS automáticamente).

## Notas

- Esta es una **plantilla**: los nombres de entidades (`products`, en vez
  de `menu_items`, `ingredients`, etc. de tu proyecto real de Biconoirs)
  están simplificados a propósito para que sea fácil de adaptar a
  cualquier dominio (tienda, restaurante, reservas...).
- Los tres proyectos comparten la misma base de datos Supabase pero cada
  uno tiene su propia responsabilidad — así se justifica tenerlos en
  instancias separadas.
- El `JWT_SECRET` debe ser idéntico en ambos backends: es lo que permite
  que Business Logic valide un token emitido por Class Operations.
