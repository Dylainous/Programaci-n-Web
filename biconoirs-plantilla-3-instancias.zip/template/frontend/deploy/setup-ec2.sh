#!/bin/bash
# Requisito 9: HTTPS con AWS + DuckDNS
# Uso: ./setup-ec2.sh tu-subdominio-frontend.duckdns.org
set -e

DOMAIN="${1:-biconoirs-app.duckdns.org}"
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "=== Instalando dependencias del sistema ==="
sudo dnf update -y
sudo dnf install -y nginx certbot python3-certbot-nginx

echo "=== Instalando Node.js 22 (solo para compilar el build) ==="
if ! command -v node &> /dev/null; then
  curl -fsSL https://rpm.nodesource.com/setup_22.x | sudo bash -
  sudo dnf install -y nodejs
fi

echo "=== Compilando el frontend (build estático) ==="
cd "$APP_DIR"
npm install
npm run build   # genera la carpeta dist/

echo "=== Configurando Nginx para servir archivos estáticos ==="
sudo rm -f /etc/nginx/conf.d/*.conf
sudo mkdir -p /var/www/biconoirs-app
sudo cp -r dist/* /var/www/biconoirs-app/

cat <<NGINX | sudo tee /etc/nginx/conf.d/biconoirs-app.conf > /dev/null
server {
    listen 80;
    server_name $DOMAIN;
    root /var/www/biconoirs-app;
    index index.html;

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}
NGINX

sudo nginx -t
sudo systemctl enable nginx
sudo systemctl restart nginx

echo "=== Solicitando certificado SSL con Certbot ==="
sudo certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN" --redirect

echo ""
echo "=== LISTO ==="
echo "Frontend: https://$DOMAIN"
echo ""
echo "IMPORTANTE: antes de 'npm run build' asegúrate de que .env tenga"
echo "VITE_CLASS_OPS_URL y VITE_BUSINESS_LOGIC_URL apuntando a los dominios HTTPS"
echo "de los otros dos backends (Vite incrusta esas variables en el build)."
