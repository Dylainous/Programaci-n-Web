// Cliente HTTP mínimo para hablar con los dos backends.
//
// Nota sobre el requisito 8 (caché): aquí SOLO guardamos el token de sesión
// en localStorage (para que ambas pestañas se identifiquen como el mismo
// usuario). El CONTENIDO del carrito nunca se guarda en el navegador: cada
// vez que se pide, viaja desde la caché de Redis en el backend. Por eso,
// abrir una pestaña nueva y consultar el carrito ya lo muestra actualizado.
const CLASS_OPS_URL = import.meta.env.VITE_CLASS_OPS_URL;
const BUSINESS_LOGIC_URL = import.meta.env.VITE_BUSINESS_LOGIC_URL;

const TOKEN_KEY = 'biconoirs_token';

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request(baseUrl, path, options = {}) {
  const token = getToken();

  const response = await fetch(`${baseUrl}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });

  if (response.status === 204) return null;

  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Error de red');
  return data;
}

// --- Backend Class Operations ---
export const classOps = {
  signup: (body) => request(CLASS_OPS_URL, '/auth/signup', { method: 'POST', body: JSON.stringify(body) }),
  login: (body) => request(CLASS_OPS_URL, '/auth/login', { method: 'POST', body: JSON.stringify(body) }),
  listProducts: () => request(CLASS_OPS_URL, '/products'),
  getCart: () => request(CLASS_OPS_URL, '/cart'),
  addToCart: (productId, quantity) =>
    request(CLASS_OPS_URL, '/cart', { method: 'POST', body: JSON.stringify({ productId, quantity }) }),
  runBlockingExample: () => request(CLASS_OPS_URL, '/examples/blocking'),
  runNonBlockingExample: () => request(CLASS_OPS_URL, '/examples/non-blocking'),
  health: () => request(CLASS_OPS_URL, '/health'),
};

// --- Backend Business Logic ---
export const businessLogic = {
  checkout: () => request(BUSINESS_LOGIC_URL, '/checkout', { method: 'POST' }),
  listOrders: () => request(BUSINESS_LOGIC_URL, '/orders'),
};
