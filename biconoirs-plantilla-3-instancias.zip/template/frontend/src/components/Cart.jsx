import { useEffect, useState } from 'react';
import { classOps, businessLogic } from '../api';

// Requisito 8: este componente evidencia el comportamiento de la caché.
// Cada vez que se monta (por ejemplo, al abrir una pestaña nueva sesionada
// con el mismo usuario), pide el carrito al backend. El campo "source" que
// devuelve el backend indica si vino de Redis ("cache") o de Postgres
// ("database" — solo la primera vez o tras expirar el TTL).
export default function Cart({ refreshSignal }) {
  const [items, setItems] = useState([]);
  const [source, setSource] = useState(null);
  const [error, setError] = useState('');
  const [checkingOut, setCheckingOut] = useState(false);
  const [orderResult, setOrderResult] = useState(null);

  async function loadCart() {
    try {
      const data = await classOps.getCart();
      setItems(data.items);
      setSource(data.source);
    } catch (err) {
      setError(err.message);
    }
  }

  useEffect(() => {
    loadCart();
  }, [refreshSignal]);

  async function handleCheckout() {
    setCheckingOut(true);
    setError('');
    try {
      const data = await businessLogic.checkout();
      setOrderResult(data.order);
      await loadCart();
    } catch (err) {
      setError(err.message);
    } finally {
      setCheckingOut(false);
    }
  }

  const total = items.reduce((sum, i) => sum + Number(i.price) * i.quantity, 0);

  return (
    <div className="panel">
      <div className="panel-label">
        <span className="dot" /> class-operations · /cart (redis cache)
      </div>
      <h2>
        Carrito{' '}
        {source && <span className={`badge ${source}`}>{source === 'cache' ? 'desde caché' : 'desde bd'}</span>}
      </h2>

      {items.length === 0 && <p className="muted">Vacío. Agrega productos desde el catálogo.</p>}

      {items.map((i) => (
        <div className="item-row" key={i.product_id}>
          <span>{i.name} × {i.quantity}</span>
          <span>${(Number(i.price) * i.quantity).toFixed(2)}</span>
        </div>
      ))}

      {items.length > 0 && (
        <>
          <div className="item-row" style={{ fontWeight: 600 }}>
            <span>Total</span>
            <span>${total.toFixed(2)}</span>
          </div>
          <button className="primary" style={{ marginTop: '0.75rem' }} onClick={handleCheckout} disabled={checkingOut}>
            {checkingOut ? 'Procesando...' : 'Finalizar compra (business-logic)'}
          </button>
        </>
      )}

      <button style={{ marginTop: '0.5rem' }} onClick={loadCart}>
        Refrescar carrito
      </button>

      {orderResult && (
        <p className="muted" style={{ marginTop: '0.5rem' }}>
          Orden creada: {orderResult.id} · total ${Number(orderResult.total).toFixed(2)}
        </p>
      )}

      {error && <p className="error-msg">{error}</p>}

      <p className="muted" style={{ marginTop: '0.75rem' }}>
        Tip: abre esta misma página en otra pestaña (sesión ya guardada) y
        pulsa "Refrescar carrito" — verás el mismo contenido, servido desde Redis.
      </p>
    </div>
  );
}
