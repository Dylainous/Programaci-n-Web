import { useEffect, useState } from 'react';
import { classOps } from '../api';

export default function Catalog({ onAdded }) {
  const [products, setProducts] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    classOps.listProducts().then(setProducts).catch((err) => setError(err.message));
  }, []);

  async function addToCart(productId) {
    try {
      await classOps.addToCart(productId, 1);
      onAdded();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="panel">
      <div className="panel-label">
        <span className="dot" /> class-operations · /products
      </div>
      <h2>Catálogo</h2>

      {products.map((p) => (
        <div className="item-row" key={p.id}>
          <span>{p.name} — ${Number(p.price).toFixed(2)}</span>
          <button onClick={() => addToCart(p.id)}>Agregar</button>
        </div>
      ))}

      {error && <p className="error-msg">{error}</p>}
    </div>
  );
}
