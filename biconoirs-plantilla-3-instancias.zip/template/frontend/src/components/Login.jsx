import { useState } from 'react';
import { classOps, setToken } from '../api';

export default function Login({ onLoggedIn }) {
  const [mode, setMode] = useState('login');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      if (mode === 'signup') {
        await classOps.signup({ fullName, email, password });
      }
      // Requisito 10: al hacer login recibimos el token de sesión (JWT)
      const data = await classOps.login({ email, password });
      setToken(data.token);
      onLoggedIn(data.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="panel">
      <div className="panel-label">
        <span className="dot" /> class-operations · /auth
      </div>
      <h2>{mode === 'login' ? 'Iniciar sesión' : 'Crear cuenta'}</h2>

      <form onSubmit={handleSubmit}>
        {mode === 'signup' && (
          <input placeholder="Nombre completo" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
        )}
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Contraseña" value={password} onChange={(e) => setPassword(e.target.value)} required />

        <button className="primary" type="submit" disabled={loading}>
          {loading ? 'Procesando...' : mode === 'login' ? 'Entrar' : 'Registrarme'}
        </button>
      </form>

      {error && <p className="error-msg">{error}</p>}

      <p className="muted" style={{ marginTop: '0.75rem' }}>
        {mode === 'login' ? '¿No tienes cuenta? ' : '¿Ya tienes cuenta? '}
        <a href="#" onClick={() => setMode(mode === 'login' ? 'signup' : 'login')}>
          {mode === 'login' ? 'Regístrate' : 'Inicia sesión'}
        </a>
      </p>
    </div>
  );
}
