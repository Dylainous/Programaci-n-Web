import { useState } from 'react';
import { classOps } from '../api';

// Requisitos 12 y 13: dispara ambos endpoints y, mientras corren, hace ping
// a /health en paralelo para visualizar la diferencia entre un proceso que
// bloquea el event loop y uno que no.
export default function ExamplesPanel() {
  const [log, setLog] = useState([]);
  const [running, setRunning] = useState(false);

  function pushLog(line) {
    setLog((prev) => [...prev, line]);
  }

  async function runDemo(type) {
    setRunning(true);
    setLog([]);
    const start = Date.now();

    pushLog(`[0ms] Disparando /examples/${type}...`);

    const mainCall =
      type === 'blocking' ? classOps.runBlockingExample() : classOps.runNonBlockingExample();

    // Mientras el endpoint pesado corre, intentamos pegarle a /health
    const pingInterval = setInterval(async () => {
      const t0 = Date.now();
      try {
        await classOps.health();
        pushLog(`[${Date.now() - start}ms] /health respondió en ${Date.now() - t0}ms`);
      } catch {
        pushLog(`[${Date.now() - start}ms] /health falló`);
      }
    }, 300);

    const result = await mainCall;
    clearInterval(pingInterval);

    pushLog(`[${Date.now() - start}ms] /examples/${type} terminó (elapsedMs: ${result.elapsedMs})`);
    setRunning(false);
  }

  return (
    <div className="panel">
      <div className="panel-label">
        <span className="dot" /> class-operations · /examples
      </div>
      <h2>Blocking vs Non-blocking</h2>
      <p className="muted">
        Corre cada ejemplo y observa si los pings a /health se retrasan (bloqueante)
        o siguen respondiendo con normalidad (no bloqueante).
      </p>

      <button onClick={() => runDemo('blocking')} disabled={running}>
        Probar bloqueante
      </button>{' '}
      <button onClick={() => runDemo('non-blocking')} disabled={running}>
        Probar no bloqueante
      </button>

      {log.length > 0 && <div className="result-box">{log.join('\n')}</div>}
    </div>
  );
}
