import { useState } from 'react';
import { getToken, clearToken } from './api';
import Login from './components/Login.jsx';
import Catalog from './components/Catalog.jsx';
import Cart from './components/Cart.jsx';
import ExamplesPanel from './components/ExamplesPanel.jsx';

export default function App() {
  const [user, setUser] = useState(null);
  const [refreshSignal, setRefreshSignal] = useState(0);
  const [loggedIn, setLoggedIn] = useState(Boolean(getToken()));

  function handleLogout() {
    clearToken();
    setLoggedIn(false);
    setUser(null);
  }

  return (
    <div className="app">
      <header className="app-header">
        <div className="eyebrow">frontend · ec2 instancia #1</div>
        <h1>Biconoirs — Plantilla de 3 instancias</h1>
        <p>
          Este frontend habla por HTTPS con dos backends independientes: uno de
          operaciones de clase (auth, catálogo, carrito con caché) y otro de
          lógica de negocio (checkout, órdenes).
        </p>
        {loggedIn && (
          <button onClick={handleLogout} style={{ marginTop: '0.5rem' }}>
            Cerrar sesión
          </button>
        )}
      </header>

      {!loggedIn ? (
        <Login onLoggedIn={(u) => { setUser(u); setLoggedIn(true); }} />
      ) : (
        <div className="grid">
          <Catalog onAdded={() => setRefreshSignal((n) => n + 1)} />
          <Cart refreshSignal={refreshSignal} />
          <ExamplesPanel />
        </div>
      )}
    </div>
  );
}
