// Requisito 8: Implementación de memoria caché
//
// Usamos Redis como caché "server-side" para el carrito de compras.
// La idea clave: el carrito NO se guarda en localStorage/sessionStorage del
// navegador (eso solo sincronizaría pestañas del MISMO navegador). En su
// lugar, el carrito vive en Redis, indexado por el id del usuario. Como el
// token de sesión (JWT) identifica al mismo usuario sin importar la pestaña,
// cualquier pestaña que llame GET /cart obtiene el mismo carrito cacheado.
require('dotenv').config();
const { createClient } = require('redis');

const redisClient = createClient({
  url: process.env.REDIS_URL,
});

redisClient.on('error', (err) => console.error('❌ Error en cliente Redis:', err));
redisClient.on('connect', () => console.log('✅ Conectado a Redis (cache de carritos)'));

async function connectRedis() {
  if (!redisClient.isOpen) {
    await redisClient.connect();
  }
}

module.exports = { redisClient, connectRedis };
