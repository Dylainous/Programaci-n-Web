// Autenticación: registro y login. Emite el token de sesión (requisito 10).
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');

// Requisito 7: método asíncrono (async/await) de ejemplo.
// Todo el flujo de signup es async: hashear password (I/O-bound en libuv,
// no bloquea el event loop) + insertar en la base de datos.
async function signup(req, res) {
  const { fullName, email, password } = req.body;

  if (!fullName || !email || !password) {
    return res.status(400).json({ error: 'fullName, email y password son requeridos' });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 10); // async -> no bloqueante

    const result = await pool.query(
      `insert into users (full_name, email, password_hash)
       values ($1, $2, $3)
       returning id, full_name, email, role, created_at`,
      [fullName, email, passwordHash],
    );

    return res.status(201).json(result.rows[0]);
  } catch (err) {
    if (err.code === '23505') {
      return res.status(409).json({ error: 'Ese email ya está registrado' });
    }
    console.error(err);
    return res.status(500).json({ error: 'Error interno al registrar el usuario' });
  }
}

async function login(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'email y password son requeridos' });
  }

  try {
    const result = await pool.query('select * from users where email = $1', [email]);
    const user = result.rows[0];

    if (!user) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const passwordMatches = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatches) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    // Requisito 10: se genera un JWT que representa la sesión del usuario.
    // El mismo secreto (JWT_SECRET) es compartido con el backend Business Logic
    // para que ambos backends puedan validar el mismo token.
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '2h' },
    );

    return res.json({
      token,
      expiresIn: '2h',
      user: { id: user.id, fullName: user.full_name, email: user.email, role: user.role },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al iniciar sesión' });
  }
}

module.exports = { signup, login };
