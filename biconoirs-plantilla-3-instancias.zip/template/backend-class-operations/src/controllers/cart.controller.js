// Requisito 8: Implementación de memoria caché
//
// Patrón usado: "cache-aside" con escritura "write-through".
//   - GET /cart  -> primero busca en Redis; si no está, consulta Postgres y
//                   llena la caché.
//   - POST /cart -> escribe en Postgres (fuente de verdad) y de inmediato
//                   actualiza la caché con el resultado nuevo.
//
// Efecto observable: un cliente inicia sesión y agrega productos al carrito.
// Si abre una segunda pestaña con el mismo login, el GET /cart de esa pestaña
// nueva lee el MISMO valor cacheado en Redis (asociado a su user_id), por lo
// que ve el carrito ya actualizado sin volver a armarlo.
const pool = require('../db');
const { redisClient } = require('../cache/redisClient');

const CACHE_TTL_SECONDS = 60 * 60; // 1 hora
const cartKey = (userId) => `cart:${userId}`;

async function fetchCartFromDb(userId) {
  const result = await pool.query(
    `select ci.product_id, ci.quantity, p.name, p.price
     from cart_items ci
     join products p on p.id = ci.product_id
     where ci.user_id = $1
     order by ci.updated_at desc`,
    [userId],
  );
  return result.rows;
}

async function getCart(req, res) {
  const userId = req.user.id;

  try {
    const cached = await redisClient.get(cartKey(userId));
    if (cached) {
      return res.json({ source: 'cache', items: JSON.parse(cached) });
    }

    const items = await fetchCartFromDb(userId);
    await redisClient.set(cartKey(userId), JSON.stringify(items), { EX: CACHE_TTL_SECONDS });

    return res.json({ source: 'database', items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error obteniendo el carrito' });
  }
}

async function addItem(req, res) {
  const userId = req.user.id;
  const { productId, quantity } = req.body;

  if (!productId || !quantity || quantity <= 0) {
    return res.status(400).json({ error: 'productId y quantity (> 0) son requeridos' });
  }

  try {
    await pool.query(
      `insert into cart_items (user_id, product_id, quantity)
       values ($1, $2, $3)
       on conflict (user_id, product_id)
       do update set quantity = cart_items.quantity + excluded.quantity, updated_at = now()`,
      [userId, productId, quantity],
    );

    const items = await fetchCartFromDb(userId);

    // Write-through: actualizamos la caché justo después de escribir en la DB
    // para que la próxima lectura (desde cualquier pestaña) ya esté al día.
    await redisClient.set(cartKey(userId), JSON.stringify(items), { EX: CACHE_TTL_SECONDS });

    return res.status(201).json({ items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error agregando el producto al carrito' });
  }
}

async function clearCart(req, res) {
  const userId = req.user.id;
  try {
    await pool.query('delete from cart_items where user_id = $1', [userId]);
    await redisClient.del(cartKey(userId));
    res.status(204).send();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error vaciando el carrito' });
  }
}

module.exports = { getCart, addItem, clearCart };
