// "Class Operations": operaciones CRUD sobre la entidad Product.
// Este backend concentra el mantenimiento de las "clases"/entidades del
// sistema (usuarios, productos, carrito), mientras que las REGLAS DE NEGOCIO
// (checkout, cálculo de totales, órdenes) viven en el backend Business Logic.
const pool = require('../db');

async function listProducts(req, res) {
  const result = await pool.query(
    'select * from products where is_active = true order by created_at desc',
  );
  res.json(result.rows);
}

async function getProduct(req, res) {
  const { id } = req.params;
  const result = await pool.query('select * from products where id = $1', [id]);
  if (!result.rows[0]) return res.status(404).json({ error: 'Producto no encontrado' });
  res.json(result.rows[0]);
}

async function createProduct(req, res) {
  const { name, description, price, stock } = req.body;
  const result = await pool.query(
    `insert into products (name, description, price, stock)
     values ($1, $2, $3, $4) returning *`,
    [name, description, price, stock ?? 0],
  );
  res.status(201).json(result.rows[0]);
}

async function updateProduct(req, res) {
  const { id } = req.params;
  const { name, description, price, stock, isActive } = req.body;
  const result = await pool.query(
    `update products set
       name = coalesce($1, name),
       description = coalesce($2, description),
       price = coalesce($3, price),
       stock = coalesce($4, stock),
       is_active = coalesce($5, is_active)
     where id = $6
     returning *`,
    [name, description, price, stock, isActive, id],
  );
  if (!result.rows[0]) return res.status(404).json({ error: 'Producto no encontrado' });
  res.json(result.rows[0]);
}

async function deleteProduct(req, res) {
  const { id } = req.params;
  await pool.query('update products set is_active = false where id = $1', [id]);
  res.status(204).send();
}

module.exports = { listProducts, getProduct, createProduct, updateProduct, deleteProduct };
