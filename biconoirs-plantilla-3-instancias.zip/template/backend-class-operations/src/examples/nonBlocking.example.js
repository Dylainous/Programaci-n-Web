// Requisito 13: un proceso NO BLOQUEANTE
//
// crypto.pbkdf2 (la versión asíncrona) delega el mismo cálculo pesado al
// thread pool de libuv, en lugar de ejecutarlo en el hilo principal. Esto
// deja el event loop LIBRE para seguir atendiendo otras peticiones mientras
// el cálculo corre "en segundo plano".
//
// Cómo comprobarlo: repite la misma prueba del ejemplo bloqueante pero contra
// este endpoint -> GET /health responderá de inmediato aunque el hash aún
// no haya terminado.
const crypto = require('crypto');
const util = require('util');

const pbkdf2Async = util.promisify(crypto.pbkdf2);

// Requisito 7 (async/await) también se ilustra aquí: la función completa
// es async y usa await sobre la versión "promisificada" de pbkdf2.
async function nonBlockingHash(req, res) {
  const start = Date.now();

  const hash = await pbkdf2Async('mi-clave-secreta', 'salt', 500000, 64, 'sha512');

  const elapsedMs = Date.now() - start;

  res.json({
    tipo: 'non-blocking',
    mensaje: 'El event loop siguió libre para atender otras peticiones mientras se calculaba',
    hashPreview: hash.toString('hex').slice(0, 16) + '...',
    elapsedMs,
  });
}

module.exports = { nonBlockingHash };
