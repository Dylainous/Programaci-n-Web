// Requisito 12: un proceso BLOQUEANTE
//
// crypto.pbkdf2Sync ejecuta el cálculo de forma SÍNCRONA sobre el hilo
// principal de Node.js (el mismo hilo que atiende el event loop). Mientras
// dura el cálculo, el servidor NO puede procesar ninguna otra petición
// entrante, ni siquiera un simple GET /health.
//
// Cómo comprobarlo: abre dos terminales.
//   Terminal A: curl http://localhost:4001/examples/blocking
//   Terminal B (inmediatamente después): curl http://localhost:4001/health
// Verás que la Terminal B se queda "colgada" hasta que termina la A.
const crypto = require('crypto');

function blockingHash(req, res) {
  const start = Date.now();

  // Trabajo intencionalmente pesado y SÍNCRONO para evidenciar el bloqueo
  const hash = crypto.pbkdf2Sync('mi-clave-secreta', 'salt', 500000, 64, 'sha512');

  const elapsedMs = Date.now() - start;

  res.json({
    tipo: 'blocking',
    mensaje: 'El event loop estuvo ocupado todo este tiempo, sin atender otras peticiones',
    hashPreview: hash.toString('hex').slice(0, 16) + '...',
    elapsedMs,
  });
}

module.exports = { blockingHash };
