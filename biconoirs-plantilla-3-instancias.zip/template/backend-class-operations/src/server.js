require('dotenv').config();
const express = require('express');
const cors = require('cors');

const { connectRedis } = require('./cache/redisClient');
const authRoutes = require('./routes/auth.routes');
const productsRoutes = require('./routes/products.routes');
const cartRoutes = require('./routes/cart.routes');
const examplesRoutes = require('./routes/examples.routes');

const app = express();

app.use(
  cors({
    origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : '*',
  }),
);
app.use(express.json());

// Usado por nginx / balanceadores para verificar que el proceso sigue vivo,
// y por los ejemplos de blocking/non-blocking para ver si el server responde.
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'class-operations', time: new Date().toISOString() });
});

app.use('/auth', authRoutes);
app.use('/products', productsRoutes);
app.use('/cart', cartRoutes);
app.use('/examples', examplesRoutes);

app.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada' });
});

const PORT = process.env.PORT || 4001;

async function start() {
  await connectRedis();
  app.listen(PORT, () => {
    console.log(`🚀 Backend Class Operations escuchando en el puerto ${PORT}`);
  });
}

start();
