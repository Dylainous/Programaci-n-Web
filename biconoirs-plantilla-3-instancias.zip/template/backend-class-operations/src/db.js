// Conexión a Supabase (Postgres) usando el driver nativo "pg".
// Se usa un Pool para reutilizar conexiones entre peticiones concurrentes.
require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // Supabase requiere SSL
});

pool.on('error', (err) => {
  console.error('Error inesperado en el pool de Postgres', err);
});

module.exports = pool;
