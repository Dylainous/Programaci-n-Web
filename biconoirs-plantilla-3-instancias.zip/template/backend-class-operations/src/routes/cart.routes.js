const { Router } = require('express');
const { getCart, addItem, clearCart } = require('../controllers/cart.controller');
const { authRequired } = require('../middleware/auth.middleware');

const router = Router();

// Todas las rutas del carrito requieren un usuario logueado (token JWT)
router.use(authRequired);

router.get('/', getCart);
router.post('/', addItem);
router.delete('/', clearCart);

module.exports = router;
