const { Router } = require('express');
const {
  listProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
} = require('../controllers/products.controller');
const { authRequired } = require('../middleware/auth.middleware');

const router = Router();

// Lectura pública (catálogo visible sin login)
router.get('/', listProducts);
router.get('/:id', getProduct);

// Escritura protegida (requiere sesión -> requisito 10)
router.post('/', authRequired, createProduct);
router.put('/:id', authRequired, updateProduct);
router.delete('/:id', authRequired, deleteProduct);

module.exports = router;
