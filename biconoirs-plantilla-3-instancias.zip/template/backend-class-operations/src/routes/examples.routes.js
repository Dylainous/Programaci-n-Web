const { Router } = require('express');
const { blockingHash } = require('../examples/blocking.example');
const { nonBlockingHash } = require('../examples/nonBlocking.example');

const router = Router();

// Requisitos 12 y 13: comparación lado a lado de bloqueante vs no bloqueante
router.get('/blocking', blockingHash);
router.get('/non-blocking', nonBlockingHash);

module.exports = router;
