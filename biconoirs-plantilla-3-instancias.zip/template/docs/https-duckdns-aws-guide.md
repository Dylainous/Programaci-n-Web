# Guía completa: HTTPS con AWS EC2 + DuckDNS (Requisito 9)

Esta guía cubre cómo publicar las **3 instancias** (frontend, backend
Class Operations, backend Business Logic) cada una en su propia instancia
de AWS EC2, con su propio subdominio DuckDNS y su propio certificado
HTTPS (Let's Encrypt vía Certbot).

## 0. Resumen de la arquitectura

```
 Navegador
    │  HTTPS
    ▼
https://biconoirs-app.duckdns.org         (EC2 #1 · Frontend · nginx sirve el build de Vite)
    │
    │  fetch() HTTPS
    ├──────────────► https://biconoirs-classops.duckdns.org   (EC2 #2 · Backend Class Operations · Node/Express :4001)
    │                        │
    │                        ├── Postgres (Supabase, gestionado, fuera de las EC2)
    │                        └── Redis (Redis Cloud, gestionado, cache del carrito)
    │
    └──────────────► https://biconoirs-business.duckdns.org   (EC2 #3 · Backend Business Logic · Node/Express :4002)
                             │
                             ├── Postgres (misma base de Supabase)
                             └── llama por HTTPS a Class Operations para leer el carrito
```

Las 3 instancias corren **Amazon Linux 2023** con **nginx** como proxy
inverso hacia el proceso de Node (gestionado con **PM2**), y **Certbot**
para emitir/renovar los certificados TLS.

## 1. Crear las 3 instancias EC2

Repite esto 3 veces (una por instancia: `frontend`, `class-ops`, `business-logic`):

1. AWS Console → EC2 → **Launch instance**
2. AMI: **Amazon Linux 2023**
3. Tipo: `t2.micro` o `t3.micro` (nivel gratuito alcanza para una plantilla/demo)
4. Crea o reutiliza un **key pair** (.pem) para conectarte por SSH
5. **Security Group** — abre estos puertos de entrada:

   | Puerto | Protocolo | Origen        | Para qué |
   |--------|-----------|---------------|----------|
   | 22     | TCP       | Tu IP         | SSH |
   | 80     | TCP       | 0.0.0.0/0     | HTTP (necesario para que Certbot valide el dominio) |
   | 443    | TCP       | 0.0.0.0/0     | HTTPS |

   No es necesario abrir el puerto 4001/4002 al público: nginx hace de
   proxy inverso hacia `127.0.0.1:4001`/`127.0.0.1:4002` dentro de la
   misma máquina.

6. Lanza la instancia.

### 1.1 Asigna una Elastic IP a cada instancia

Por defecto, la IP pública de una EC2 cambia si la reinicias. Para que tu
dominio DuckDNS no deje de apuntar a tu servidor:

EC2 → **Elastic IPs** → **Allocate Elastic IP address** → **Associate** con
cada una de las 3 instancias. Repite 3 veces (una Elastic IP por instancia).

## 2. Configurar DuckDNS

1. Entra a [https://www.duckdns.org](https://www.duckdns.org) e inicia sesión (con GitHub/Google/etc.)
2. Copia tu **token** (aparece arriba, es el mismo para todos tus subdominios)
3. Crea 3 subdominios, uno por instancia, y en el campo IP pon la Elastic IP correspondiente:
   - `biconoirs-app` → Elastic IP del frontend
   - `biconoirs-classops` → Elastic IP de Class Operations
   - `biconoirs-business` → Elastic IP de Business Logic
4. Click **add domain** en cada uno. Cada uno queda como
   `tu-subdominio.duckdns.org`.

Como usamos Elastic IPs fijas, técnicamente no necesitas actualizar la IP
nunca más. Si en cambio usas la IP pública dinámica de la EC2 (sin Elastic
IP), agrega este cron en cada instancia para mantener el DNS al día:

```bash
mkdir -p ~/duckdns && cd ~/duckdns
cat > duck.sh << 'EOF'
echo url="https://www.duckdns.org/update?domains=TU-SUBDOMINIO&token=TU-TOKEN&ip=" | curl -k -o duck.log -K -
EOF
chmod +x duck.sh
(crontab -l 2>/dev/null; echo "*/5 * * * * ~/duckdns/duck.sh >/dev/null 2>&1") | crontab -
```

## 3. Subir el código a cada instancia

Conéctate por SSH:

```bash
ssh -i tu-llave.pem ec2-user@<elastic-ip>
```

Sube el código (con `scp`, `git clone`, o el método que prefieras). Por
ejemplo, para el backend de Class Operations:

```bash
scp -i tu-llave.pem -r backend-class-operations ec2-user@<elastic-ip>:~/app
```

Copia `.env.example` a `.env` dentro de cada carpeta y completa los
valores reales (cadena de conexión de Supabase, URL de Redis, JWT_SECRET,
CORS_ORIGIN, etc. — ver el `.env.example` de cada proyecto).

## 4. Ejecutar el script de despliegue

Cada uno de los 3 proyectos trae un script `deploy/setup-ec2.sh` que:

- Instala nginx, Certbot y Node.js 22
- Instala las dependencias del proyecto (`npm install`)
- Levanta el proceso con PM2 (o compila y sirve el build estático, en el
  caso del frontend)
- Configura nginx como proxy inverso (o servidor de archivos estáticos)
- Pide el certificado HTTPS con Certbot y configura la redirección
  HTTP → HTTPS automáticamente

Ejecútalo pasando el subdominio correspondiente:

```bash
# Dentro de la instancia de Class Operations
cd ~/app
chmod +x deploy/setup-ec2.sh
./deploy/setup-ec2.sh biconoirs-classops.duckdns.org

# Dentro de la instancia de Business Logic
./deploy/setup-ec2.sh biconoirs-business.duckdns.org

# Dentro de la instancia del Frontend (después de configurar su .env
# con las URLs HTTPS de los dos backends)
./deploy/setup-ec2.sh biconoirs-app.duckdns.org
```

## 5. Verificar

```bash
curl https://biconoirs-classops.duckdns.org/health
curl https://biconoirs-business.duckdns.org/health
```

Y abre `https://biconoirs-app.duckdns.org` en el navegador — debería
cargar el frontend y poder hacer login/carrito/checkout contra los otros
dos backends por HTTPS.

## 6. Renovación del certificado

Certbot en Amazon Linux instala un temporizador de systemd que renueva
automáticamente los certificados antes de que expiren (duran 90 días).
Para confirmarlo:

```bash
sudo systemctl status certbot-renew.timer
sudo certbot renew --dry-run
```

## 7. Errores comunes

- **Certbot falla con "Timeout during connect"**: revisa que el puerto 80
  esté abierto en el Security Group y que el subdominio DuckDNS apunte a
  la Elastic IP correcta (`nslookup tu-subdominio.duckdns.org`).
- **CORS bloqueado en el navegador**: agrega el dominio HTTPS del
  frontend a la variable `CORS_ORIGIN` de ambos backends y reinicia con
  `pm2 restart all`.
- **El checkout falla con 502**: normalmente significa que
  `CLASS_OPS_URL` en el `.env` de Business Logic no apunta al dominio
  HTTPS correcto de Class Operations.
