// Requisito 10: Sesión de usuario con token
//
// Este middleware valida el JWT enviado en el header "Authorization: Bearer <token>".
// Si es válido, adjunta la info del usuario (id, email, role) en req.user para
// que los controladores sepan de quién es la petición sin volver a consultar la DB.
const jwt = require('jsonwebtoken');

function authRequired(req, res, next) {
  const header = req.headers.authorization;

  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Token no proporcionado' });
  }

  const token = header.split(' ')[1];

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { id, email, role, iat, exp }
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token inválido o expirado' });
  }
}

module.exports = { authRequired };
