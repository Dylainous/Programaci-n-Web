require('dotenv').config();
const express = require('express');
const cors = require('cors');

const checkoutRoutes = require('./routes/checkout.routes');
const ordersRoutes = require('./routes/orders.routes');

const app = express();

app.use(
  cors({
    origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : '*',
  }),
);
app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'business-logic', time: new Date().toISOString() });
});

app.use('/checkout', checkoutRoutes);
app.use('/orders', ordersRoutes);

app.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada' });
});

const PORT = process.env.PORT || 4002;

app.listen(PORT, () => {
  console.log(`🚀 Backend Business Logic escuchando en el puerto ${PORT}`);
});
