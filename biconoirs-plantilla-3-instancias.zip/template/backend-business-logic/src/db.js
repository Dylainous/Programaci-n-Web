// Misma base de datos Supabase que Class Operations: ambos backends
// comparten la fuente de verdad (Postgres), cada uno responsable de
// una parte distinta del dominio.
require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false },
});

pool.on('error', (err) => {
  console.error('Error inesperado en el pool de Postgres', err);
});

module.exports = pool;
