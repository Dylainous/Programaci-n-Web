const { Router } = require('express');
const { listMyOrders, getOrderDetail } = require('../controllers/orders.controller');
const { authRequired } = require('../middleware/auth.middleware');

const router = Router();

router.use(authRequired);

router.get('/', listMyOrders);
router.get('/:id', getOrderDetail);

module.exports = router;
