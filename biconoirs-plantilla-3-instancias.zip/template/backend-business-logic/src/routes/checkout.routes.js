const { Router } = require('express');
const { checkout } = require('../controllers/checkout.controller');
const { authRequired } = require('../middleware/auth.middleware');

const router = Router();

router.post('/', authRequired, checkout);

module.exports = router;
