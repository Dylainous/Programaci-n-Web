const pool = require('../db');

async function listMyOrders(req, res) {
  const userId = req.user.id;

  const orders = await pool.query(
    'select * from orders where user_id = $1 order by created_at desc',
    [userId],
  );

  res.json(orders.rows);
}

async function getOrderDetail(req, res) {
  const userId = req.user.id;
  const { id } = req.params;

  const order = await pool.query('select * from orders where id = $1 and user_id = $2', [
    id,
    userId,
  ]);

  if (!order.rows[0]) return res.status(404).json({ error: 'Orden no encontrada' });

  const items = await pool.query(
    `select oi.*, p.name from order_items oi join products p on p.id = oi.product_id where order_id = $1`,
    [id],
  );

  res.json({ order: order.rows[0], items: items.rows });
}

module.exports = { listMyOrders, getOrderDetail };
