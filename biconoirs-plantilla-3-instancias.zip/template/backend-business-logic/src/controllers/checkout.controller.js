// Reglas de negocio del checkout: este backend NO conoce el carrito
// directamente; se lo pide al backend Class Operations por HTTPS (usa la
// caché de Redis de ese servicio) y luego aplica lógica propia: validar
// stock, calcular el total y persistir la orden.
const pool = require('../db');

const CLASS_OPS_URL = process.env.CLASS_OPS_URL;

// Requisito 7: método asíncrono de ejemplo.
// Combina una llamada HTTP asíncrona (fetch) con dos consultas asíncronas a
// la base de datos, todo con async/await de forma secuencial y legible.
async function checkout(req, res) {
  const userId = req.user.id;
  const authHeader = req.headers.authorization;

  try {
    // 1) Pide el carrito actual al backend de Class Operations.
    //    (Node >= 18 trae fetch de forma nativa, sin dependencias extra.)
    const cartResponse = await fetch(`${CLASS_OPS_URL}/cart`, {
      headers: { Authorization: authHeader },
    });

    if (!cartResponse.ok) {
      return res.status(502).json({ error: 'No se pudo obtener el carrito del usuario' });
    }

    const { items } = await cartResponse.json();

    if (!items || items.length === 0) {
      return res.status(400).json({ error: 'El carrito está vacío' });
    }

    // 2) Regla de negocio: calcular el total en el servidor (nunca confiar
    //    en un total calculado en el frontend).
    const total = items.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);

    // 3) Persistir la orden y sus líneas dentro de la misma "operación lógica"
    const orderResult = await pool.query(
      `insert into orders (user_id, status, total) values ($1, 'pending', $2) returning *`,
      [userId, total],
    );
    const order = orderResult.rows[0];

    for (const item of items) {
      await pool.query(
        `insert into order_items (order_id, product_id, quantity, unit_price)
         values ($1, $2, $3, $4)`,
        [order.id, item.product_id, item.quantity, item.price],
      );
    }

    // 4) Vaciar el carrito una vez confirmada la orden
    await fetch(`${CLASS_OPS_URL}/cart`, {
      method: 'DELETE',
      headers: { Authorization: authHeader },
    });

    return res.status(201).json({ order, items });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error procesando el checkout' });
  }
}

module.exports = { checkout };
