#!/bin/bash
# Requisito 9: HTTPS con AWS + DuckDNS
# Uso: ./setup-ec2.sh tu-subdominio-business.duckdns.org
set -e

DOMAIN="${1:-biconoirs-business.duckdns.org}"
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "=== Instalando dependencias del sistema ==="
sudo dnf update -y
sudo dnf install -y nginx certbot python3-certbot-nginx

echo "=== Instalando Node.js 22 ==="
if ! command -v node &> /dev/null; then
  curl -fsSL https://rpm.nodesource.com/setup_22.x | sudo bash -
  sudo dnf install -y nodejs
fi

echo "=== Instalando dependencias del proyecto ==="
cd "$APP_DIR"
npm install --omit=dev

echo "=== Configurando PM2 ==="
if ! command -v pm2 &> /dev/null; then
  sudo npm install -g pm2
fi

pm2 delete biconoirs-business-logic 2>/dev/null || true
pm2 start src/server.js --name "biconoirs-business-logic"
pm2 save

echo "=== Configurando Nginx (HTTP inicial, para Certbot) ==="
sudo rm -f /etc/nginx/conf.d/*.conf

cat <<NGINX | sudo tee /etc/nginx/conf.d/biconoirs-business-logic.conf > /dev/null
server {
    listen 80;
    server_name $DOMAIN;

    location / {
        proxy_pass http://127.0.0.1:4002;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 60s;
        proxy_send_timeout 60s;
    }
}
NGINX

sudo nginx -t
sudo systemctl enable nginx
sudo systemctl restart nginx

echo "=== Solicitando certificado SSL con Certbot ==="
sudo certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos -m "admin@$DOMAIN" --redirect

echo ""
echo "=== LISTO ==="
echo "Backend Business Logic: https://$DOMAIN"
echo "Prueba con: curl https://$DOMAIN/health"
