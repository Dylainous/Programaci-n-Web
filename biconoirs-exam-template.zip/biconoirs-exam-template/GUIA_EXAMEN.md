# Guía para el examen: plantilla con ORM (Prisma) y dos instancias AWS

Esta plantilla es la versión "con ORM" de `exam-api-template` (la
plantilla anterior, en SQL puro con `pg`). Úsala si en el examen te
piden explícitamente **ORM** (Prisma) o una arquitectura de **dos
instancias** donde una consume a la otra.

Si te piden SQL puro sin ORM, usa la plantilla `exam-api-template`.
Si te piden ORM y/o dos instancias, usa ESTA.

---

## 1. Arquitectura general

```
┌─────────────────────────────┐        ┌─────────────────────────────┐
│   INSTANCIA 1 (AWS)          │        │   INSTANCIA 2 (AWS)          │
│   class-operations           │        │   business-logic              │
│                               │        │                               │
│   NestJS + Prisma ORM         │  HTTP  │   NestJS                     │
│   ┌─────────────────────┐    │ <----- │   ┌─────────────────────┐    │
│   │ CRUD: students        │   │  GET   │   │ Reglas de negocio:    │   │
│   │ POST   /api/students  │   │        │   │  - average (1 reg.)   │   │
│   │ GET    /api/students  │◄──┼────────┼──►│  - ranking  (lista)   │   │
│   │ GET    /api/students/:id│  │        │   │                       │   │
│   │ PUT    /api/students/:id│  │        │   │ GET /api/students/    │   │
│   │ DELETE /api/students/:id│  │        │   │     :id/average       │   │
│   └─────────────────────┘    │        │   │ GET /api/students/    │   │
│              │                │        │   │     ranking            │   │
│              ▼                │        │   └─────────────────────┘    │
│   Supabase PostgreSQL          │        │                               │
└─────────────────────────────┘        └─────────────────────────────┘
```

**Idea clave:** la Instancia 1 ("class operations" / "create
operations") es la ÚNICA que toca la base de datos. Hace CRUD puro
sobre las "clases" (entidades) del sistema. La Instancia 2 ("business
logic") NO tiene base de datos: cuando necesita datos, le hace una
petición HTTP a la Instancia 1, y sobre esos datos aplica los cálculos
/ reglas de negocio.

Esto es exactamente lo mismo que ya conoces de `exam-api-template`
(CRUD + reglas de negocio), pero **separado en dos servidores
distintos**, comunicados por HTTP en vez de por funciones internas.

---

## 2. ¿Qué cambia respecto a la plantilla SQL anterior?

| Aspecto | `exam-api-template` (SQL puro) | Esta plantilla (ORM) |
|---|---|---|
| Acceso a datos | `pg` + SQL escrito a mano | Prisma (`schema.prisma` + `prisma.<modelo>.findMany()`, etc.) |
| Validaciones | función `validate...Body()` manual | DTOs con decoradores `class-validator` (`@IsString`, `@Min`, etc.) |
| Errores 404 | `if (!row) return null` | capturar error `P2025` de Prisma (update/delete) o `findUnique` devuelve `null` |
| Reglas de negocio | mismo servidor, mismo archivo de rutas | **servidor separado**, que consume al primero por HTTP |
| `.env` | `DB_HOST`, `DB_PORT`, ... (directo a `pg`) | mismas variables + `scripts/with-database-url.js` construye `DATABASE_URL` para Prisma |

---

## 3. `class-operations`: Prisma y el archivo `.env`

### 3.1 `schema.prisma`

Es el equivalente a `01_create_tables.sql`. Define modelos (clases) que
Prisma convierte en tablas.

```prisma
model Student {
  id         Int      @id @default(autoincrement())
  fullName   String   @map("full_name")
  career     String
  grade1     Decimal  @map("grade_1") @db.Decimal(4, 2)
  grade2     Decimal  @map("grade_2") @db.Decimal(4, 2)
  grade3     Decimal  @map("grade_3") @db.Decimal(4, 2)
  enrolledAt DateTime @default(now()) @map("enrolled_at") @db.Timestamptz

  @@map("students")
}
```

- `@map("...")`: nombre real de la COLUMNA en la base de datos
  (snake_case), mientras el campo en TypeScript queda en camelCase.
- `@@map("...")`: nombre real de la TABLA.
- `@db.Decimal(4, 2)`: 4 dígitos totales, 2 decimales (igual que
  `NUMERIC(4,2)` en SQL).

### 3.2 ¿Por qué el `.env` usa `DB_HOST`/`DB_PORT`/... y no `DATABASE_URL`?

Prisma **siempre** necesita una variable `DATABASE_URL` con formato:

```
postgresql://usuario:password@host:puerto/basededatos
```

Pero querías mantener el MISMO formato de `.env` (`DB_HOST`, `DB_PORT`,
`DB_NAME`, `DB_USER`, `DB_PASSWORD`, `PORT`) que ya usas en los
proyectos Express/pg. Para lograr ambas cosas sin escribir
`DATABASE_URL` a mano, esta plantilla incluye
`scripts/with-database-url.js`:

1. Lee tu `.env` (con el formato `DB_HOST`/`DB_PORT`/...).
2. Construye `DATABASE_URL` a partir de esas piezas.
3. Ejecuta el comando real (`prisma db push`, `nest start`, `node
   dist/main`, etc.) con `DATABASE_URL` ya disponible en su entorno.

Por eso, en `package.json`, los scripts se ven así:

```json
"dev":             "node scripts/with-database-url.js nest start --watch",
"prisma:generate": "node scripts/with-database-url.js prisma generate",
"prisma:push":     "node scripts/with-database-url.js prisma db push"
```

**No necesitas modificar este script ni entender `dotenv-expand`**: solo
llena `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` en tu
`.env`, igual que en la plantilla anterior.

### 3.3 Comandos típicos del flujo de trabajo

```bash
npm install
npm run prisma:generate   # genera el cliente de Prisma (TypeScript)
npm run prisma:push       # crea/actualiza las tablas en Supabase según schema.prisma
npm run dev                # levanta el servidor en modo desarrollo
```

`prisma db push` reemplaza a "ejecutar `01_create_tables.sql` en
Supabase": lee `schema.prisma` y crea las tablas automáticamente. Para
los DATOS DE PRUEBA, sigue usando un script SQL (`prisma/seed.sql`) en
el SQL Editor de Supabase, igual que antes.

---

## 4. Diseño de URIs (CRUD + reglas de negocio)

### 4.1 Instancia 1 (`class-operations`) — CRUD

| Operación | Método | URI | Request Body | Response | HTTP éxito | HTTP error |
|---|---|---|---|---|---|---|
| Crear | `POST` | `/api/<recurso>` | JSON con los campos | objeto creado | `201` | `400` |
| Listar todos | `GET` | `/api/<recurso>` | — | arreglo | `200` | `500` |
| Obtener uno | `GET` | `/api/<recurso>/:id` | — | objeto | `200` | `404` |
| Actualizar | `PUT` | `/api/<recurso>/:id` | JSON completo | objeto actualizado | `200` | `400`, `404` |
| Eliminar | `DELETE` | `/api/<recurso>/:id` | — | mensaje | `200` | `404` |

Esta tabla es **idéntica** a la de `exam-api-template`. Lo único que
cambia es la implementación interna (Prisma en vez de SQL).

### 4.2 Instancia 2 (`business-logic`) — Reglas de negocio

| Tipo de regla | Método | URI | ¿De dónde obtiene los datos? | Response | HTTP éxito | HTTP error |
|---|---|---|---|---|---|---|
| Cálculo individual | `GET` | `/api/<recurso>/:id/<calculo>` | `GET <CLASS_OPERATIONS_API_URL>/:id` | objeto con resultado | `200` | `404`, `502`, `503` |
| Cálculo de lista | `GET` | `/api/<recurso>/<calculo>` | `GET <CLASS_OPERATIONS_API_URL>` | arreglo | `200` | `502`, `503` |

Los códigos `502`/`503` son NUEVOS respecto a la plantilla anterior:
aparecen porque ahora hay una llamada de red entre dos servidores que
puede fallar.

- `404` → el recurso `:id` no existe (igual que antes).
- `502 Bad Gateway` → `class-operations` respondió con un error.
- `503 Service Unavailable` → `business-logic` no logró conectarse a
  `class-operations` (servidor caído, URL mal configurada, etc.).

---

## 5. ¿Cómo "consume" `business-logic` a `class-operations`?

El patrón está en `business-logic/src/students/students.service.ts`.
En resumen:

```ts
// 1. URL base de la Instancia 1, leída desde .env
const baseUrl = this.config.get<string>('CLASS_OPERATIONS_API_URL');

// 2. Petición HTTP normal con fetch (disponible en Node 18+, sin
//    instalar nada extra)
const response = await fetch(`${baseUrl}/${id}`);

// 3. Manejo de estado
if (response.status === 404) { /* 404 propio */ }
if (!response.ok) { /* 502 */ }

// 4. Datos -> aplicar la regla de negocio
const student = await response.json();
const average = calculateAverage(student);
```

**Importante:** la respuesta JSON de `class-operations` (camelCase:
`fullName`, `grade1`, etc.) debe coincidir con la interfaz `Student`
que usan las funciones de cálculo en
`business-logic/src/students/students.calculations.ts`. Si cambias los
nombres de los campos en una instancia, cambia también la interfaz en
la otra.

---

## 6. Adaptar la plantilla a tu tema (checklist)

Supongamos el tema **"tienda de zapatos"**: entidad `products`, con
regla de negocio "precio final con descuento" (individual) y "listado
ordenado por precio final" (lista).

### 6.1 En `class-operations`

1. **`prisma/schema.prisma`**: renombra `Student` → `Product`, ajusta
   los campos (`name`, `price`, `discountPercentage`, etc.) y
   `@@map("products")`.
2. **`src/students/` → `src/products/`**: renombra la carpeta y los
   archivos (`students.service.ts` → `products.service.ts`, etc.).
   - En el service, cambia `this.prisma.student` → `this.prisma.product`
     y ajusta `toResponse()`.
   - En el controller, cambia `@Controller('api/students')` →
     `@Controller('api/products')`.
   - Reescribe los DTOs (`CreateProductDto`, `UpdateProductDto`) con
     las reglas de validación que pida el examen.
3. **`src/app.module.ts`**: importa `ProductsModule` en vez de
   `StudentsModule`.
4. **`npm run prisma:generate && npm run prisma:push`** para crear la
   nueva tabla.
5. **`prisma/seed.sql`**: nuevos `INSERT` para `products`.

### 6.2 En `business-logic`

1. **`src/students/students.calculations.ts` →
   `src/products/products.calculations.ts`**:
   - Cambia la interfaz `Student` por `Product` (mismos campos que
     devuelve `class-operations`).
   - Reescribe `calculateAverage` → `calculateFinalPrice` (ej.
     `price - (price * discountPercentage / 100)`).
   - Reescribe `buildRanking` → `buildCheapestList` (mismo patrón:
     map + sort + map con índice).
2. **`src/products/products.service.ts`**: cambia las rutas que
   consulta (`/api/products/:id`, `/api/products`) y los nombres de
   los métodos (`getFinalPrice`, `getCheapestList`).
3. **`src/products/products.controller.ts`**: cambia las URIs:
   - `/:id/average` → `/:id/final-price`
   - `/ranking` → `/cheapest`
4. **`src/app.module.ts`**: importa `ProductsModule`.
5. **`.env`**: `CLASS_OPERATIONS_API_URL=http://localhost:3000/api/products`

### 6.3 Orden de trabajo recomendado durante el examen

1. Diseña la tabla de URIs (sección 4) para tu entidad — 5 min.
2. `class-operations`: adapta `schema.prisma`, corre
   `prisma:generate` + `prisma:push`, adapta DTOs, service y
   controller (CRUD) — 20-25 min.
3. Prueba el CRUD de `class-operations` con Postman/Thunder Client
   ANTES de tocar `business-logic`.
4. `business-logic`: adapta `*.calculations.ts`, `service` y
   `controller` — 10-15 min.
5. Configura `CLASS_OPERATIONS_API_URL` en `business-logic/.env`
   apuntando a `class-operations` (local o AWS).
6. Prueba los endpoints de reglas de negocio.

---

## 7. Despliegue en dos instancias de AWS

Cada carpeta (`class-operations/` y `business-logic/`) es un proyecto
NestJS **independiente**: se despliega por separado (por ejemplo, dos
entornos de Elastic Beanstalk, o dos instancias EC2).

### 7.1 `class-operations` (Instancia 1)

- Variables de entorno en AWS: `DB_HOST`, `DB_PORT`, `DB_NAME`,
  `DB_USER`, `DB_PASSWORD`, `PORT`. `with-database-url.js` construye
  `DATABASE_URL` igual que en local.
- Comando de inicio: `npm start` (ejecuta `npm run build` previamente).

### 7.2 `business-logic` (Instancia 2)

- Variables de entorno en AWS:
  - `PORT`
  - `CLASS_OPERATIONS_API_URL` → **debe apuntar a la URL/IP pública de
    la Instancia 1**, por ejemplo:
    - EC2: `http://<ip-publica-instancia-1>:3000/api/students`
    - Elastic Beanstalk: `http://class-operations-env.eba-xxxx.us-east-1.elasticbeanstalk.com/api/students`

### 7.3 Checklist de despliegue

1. Desplegar `class-operations` primero y verificar que responde
   `GET /api/students` correctamente desde su URL pública.
2. Tomar esa URL pública y configurarla como
   `CLASS_OPERATIONS_API_URL` en las variables de entorno de
   `business-logic`.
3. Desplegar `business-logic` y probar
   `GET /api/students/ranking` — si responde `503`, revisa que la URL
   de la Instancia 1 sea correcta y accesible (Security Groups /
   puertos abiertos).

---

## 8. Resumen mental rápido

- **Instancia 1 = CRUD + base de datos (Prisma).** Es la única que
  conoce Supabase.
- **Instancia 2 = cálculos, sin base de datos.** Obtiene todo por
  `fetch()` desde la Instancia 1.
- **DTOs + `ValidationPipe`** reemplazan las validaciones manuales:
  decora los campos, Nest valida solo.
- **`P2025`** = "registro no encontrado" en Prisma → conviértelo en
  `404`.
- **`502`/`503`** = errores de comunicación ENTRE instancias, nuevos
  en esta arquitectura.
- **`scripts/with-database-url.js`** te permite seguir usando el
  `.env` con `DB_HOST`/`DB_PORT`/... aunque Prisma exija
  `DATABASE_URL`.
