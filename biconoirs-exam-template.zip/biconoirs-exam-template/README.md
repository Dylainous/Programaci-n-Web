# biconoirs-exam-template (ORM + 2 instancias AWS)

Plantilla con **Prisma ORM** (NestJS) dividida en **dos proyectos
independientes**, pensados para subirse a **dos instancias de AWS**:

```
biconoirs-exam-template/
├── class-operations/   # INSTANCIA 1: CRUD (Prisma + Supabase)
├── business-logic/     # INSTANCIA 2: reglas de negocio (consume Instancia 1 por HTTP)
└── GUIA_EXAMEN.md       # ← Léeme primero
```

**Empieza por `GUIA_EXAMEN.md`** — ahí está toda la explicación: la
arquitectura, el truco del `.env` para Prisma, las tablas de diseño de
URIs, y el paso a paso para adaptar la plantilla a cualquier tema de
examen.

Cada subcarpeta (`class-operations/` y `business-logic/`) tiene su
propio `README.md` con instrucciones específicas de instalación y
ejecución.

---

## Inicio rápido (local)

```bash
# Terminal 1
cd class-operations
cp .env.example .env   # completa con tus credenciales de Supabase
npm install
npm run prisma:generate
npm run prisma:push
npm run dev             # http://localhost:3000

# Terminal 2
cd business-logic
cp .env.example .env   # CLASS_OPERATIONS_API_URL=http://localhost:3000/api/students
npm install
npm run dev             # http://localhost:3001
```

Luego, en el SQL Editor de Supabase, ejecuta
`class-operations/prisma/seed.sql` para tener datos de prueba.
