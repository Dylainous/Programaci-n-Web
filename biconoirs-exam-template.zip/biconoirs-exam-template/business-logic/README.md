# business-logic (Instancia 2 — AWS)

API REST de **reglas de negocio** (cálculos). NestJS. **No tiene base
de datos propia**: obtiene los datos consumiendo la API de
`class-operations` (Instancia 1) por HTTP.

---

## Estructura

```
business-logic/
├── src/
│   ├── students/
│   │   ├── students.calculations.ts   # Reglas de negocio (funciones puras)
│   │   ├── students.controller.ts
│   │   ├── students.module.ts
│   │   └── students.service.ts        # Consume class-operations por HTTP
│   ├── app.module.ts
│   └── main.ts
├── .env.example
└── package.json
```

---

## 1. Variables de entorno

```bash
cp .env.example .env
```

```
CLASS_OPERATIONS_API_URL=http://localhost:3000/api/students
PORT=3001
```

> `CLASS_OPERATIONS_API_URL` debe apuntar a la Instancia 1
> (`class-operations`). En local, asegúrate de que esa instancia esté
> corriendo en el puerto indicado (por defecto `3000`).

## 2. Instalar y ejecutar

```bash
npm install
npm run dev     # desarrollo
npm start       # producción (requiere "npm run build" antes)
```

---

## Endpoints (reglas de negocio)

| Método | URI | Descripción | Éxito | Errores |
|--------|-----|-------------|-------|---------|
| `GET` | `/api/students/:id/average` | Promedio individual (Regla 1) | `200` | `404`, `502`, `503` |
| `GET` | `/api/students/ranking` | Ranking por promedio (Regla 2) | `200` | `502`, `503` |

### Ejemplo GET `/api/students/1/average`
```json
{ "studentId": 1, "fullName": "Ana Torres", "average": 8.43 }
```

### Ejemplo GET `/api/students/ranking`
```json
[
    { "fullName": "Diego Castillo", "average": 9.90, "ranking": 1 },
    { "fullName": "María Fernández", "average": 9.23, "ranking": 2 }
]
```

---

## Errores `502` / `503`: ¿qué significan aquí?

- **`503 Service Unavailable`**: `business-logic` no pudo conectarse a
  `class-operations` (URL incorrecta, instancia 1 apagada, etc.).
- **`502 Bad Gateway`**: `class-operations` respondió, pero con un
  error (ej. `500`).

Para probar esto durante el examen: apaga la instancia 1 y verifica que
la instancia 2 responde `503` en vez de quedarse "colgada" o caerse.
