import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

// ============================================================
// GUÍA: Punto de entrada de la INSTANCIA 2 (business-logic).
//
// "import 'dotenv/config'" carga el .env de ESTA instancia ANTES de
// que arranque cualquier otra cosa, para que
// process.env.CLASS_OPERATIONS_API_URL y process.env.PORT estén
// disponibles desde el inicio.
//
// Esta instancia NO necesita el script "with-database-url.js" (eso
// es exclusivo de class-operations, por usar Prisma).
// ============================================================

async function bootstrap() {
    const app = await NestFactory.create(AppModule);

    const port = process.env.PORT || 3001;
    await app.listen(port);
    console.log(`Business Logic API is running on port --> ${port}`);
    console.log(`Consuming class-operations at --> ${process.env.CLASS_OPERATIONS_API_URL}`);
}
bootstrap();
