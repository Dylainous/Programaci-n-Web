import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { StudentsModule } from './students/students.module';

// ============================================================
// GUÍA: A diferencia de class-operations, esta instancia NO tiene
// PrismaModule (no se conecta directamente a ninguna base de datos).
// Toda su "fuente de datos" es la API de class-operations, consumida
// por HTTP dentro de StudentsService.
//
// ConfigModule.forRoot() carga el .env de ESTA instancia
// (CLASS_OPERATIONS_API_URL, PORT).
// ============================================================

@Module({
    imports: [
        ConfigModule.forRoot({ isGlobal: true }),
        StudentsModule,
    ],
})
export class AppModule {}
