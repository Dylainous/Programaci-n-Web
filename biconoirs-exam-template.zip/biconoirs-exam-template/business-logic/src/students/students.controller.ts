import { Controller, Get, Param } from '@nestjs/common';
import { StudentsService } from './students.service';

// ============================================================
// GUÍA GENERAL DE ESTE ARCHIVO (students.controller.ts - business-logic)
//
// Esta INSTANCIA (business-logic) SOLO expone las reglas de negocio
// (cálculos). El CRUD vive en la otra instancia (class-operations).
//
//   GET /api/students/:id/average  -> Regla 1 (cálculo individual)
//   GET /api/students/ranking      -> Regla 2 (cálculo de lista)
//
// NOTA SOBRE EL ORDEN DE RUTAS:
// Aquí "ranking" (1 segmento: /api/students/ranking) y ":id/average"
// (2 segmentos: /api/students/:id/average) NO chocan entre sí porque
// tienen distinta "profundidad" de ruta. El problema de orden de la
// plantilla Express ("/ranking" antes de "/:id") solo aparece cuando
// DOS rutas tienen la MISMA cantidad de segmentos y una de ellas usa
// un parámetro (ej. "/ranking" vs "/:id"). Si en tu examen agregas
// una ruta así en esta instancia, recuerda declarar primero la de
// texto fijo.
// ============================================================

@Controller('api/students')
export class StudentsController {
    constructor(private readonly studentsService: StudentsService) {}

    // ───────────────────────────────────────────────────────────────────
    // GET /api/students/ranking   (Regla de negocio 2: ranking)
    //
    // Caso de uso: "Devuelve la lista de estudiantes ordenada por
    // promedio, de mayor a menor, indicando la posición de cada uno".
    //
    //   Método:  GET
    //   URI:     /api/students/ranking
    //   Request: sin body
    //   Response (200):
    //     [
    //       { "fullName": "Diego Castillo", "average": 9.90, "ranking": 1 },
    //       { "fullName": "María Fernández", "average": 9.23, "ranking": 2 }
    //     ]
    //   Errores:
    //     - 502/503 si class-operations no responde correctamente
    // ───────────────────────────────────────────────────────────────────
    @Get('ranking')
    getRanking() {
        return this.studentsService.getRanking();
    }

    // ───────────────────────────────────────────────────────────────────
    // GET /api/students/:id/average   (Regla de negocio 1: cálculo individual)
    //
    // Caso de uso: "Calcular el promedio de notas de un estudiante
    // específico, obteniendo sus datos desde class-operations".
    //
    //   Método:  GET
    //   URI:     /api/students/:id/average
    //   Request: sin body
    //   Response (200):
    //     { "studentId": 1, "fullName": "Ana Torres", "average": 8.43 }
    //   Errores:
    //     - 404 si el estudiante no existe en class-operations
    //     - 502/503 si class-operations no responde correctamente
    // ───────────────────────────────────────────────────────────────────
    @Get(':id/average')
    getAverage(@Param('id') id: string) {
        return this.studentsService.getAverage(id);
    }
}
