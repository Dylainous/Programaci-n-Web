import {
    BadGatewayException,
    Injectable,
    NotFoundException,
    ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Student, calculateAverage, buildRanking } from './students.calculations';

// ============================================================
// GUÍA GENERAL DE ESTE ARCHIVO (students.service.ts - business-logic)
//
// Este es el archivo MÁS IMPORTANTE para entender la arquitectura de
// dos instancias: aquí es donde la Instancia 2 "CONSUME" a la
// Instancia 1.
//
// En lugar de "this.prisma.student.findMany()" (como en
// class-operations), aquí hacemos una petición HTTP normal con
// fetch() hacia la URL pública de class-operations
// (CLASS_OPERATIONS_API_URL, definida en .env).
//
// Patrón general para "consumir" otra instancia:
//   1. Construye la URL completa (base + recurso/id).
//   2. await fetch(url)
//   3. Revisa response.status (404 -> not found, !ok -> error).
//   4. await response.json() para obtener los datos.
//   5. Aplica la regla de negocio (calculateAverage / buildRanking)
//      SOBRE esos datos, igual que harías si vinieran de tu propia BD.
//
// CÓMO ADAPTAR A TU TEMA:
//   - Cambia "calculateAverage"/"buildRanking" por las funciones de
//     students.calculations.ts que hayas reescrito.
//   - Si necesitas más de un recurso (ej. "products" Y "categories"),
//     agrega más variables de entorno
//     (PRODUCTS_API_URL, CATEGORIES_API_URL) y repite el patrón.
// ============================================================

@Injectable()
export class StudentsService {
    constructor(private readonly config: ConfigService) {}

    // GUÍA: URL base de la Instancia 1, ej:
    //   http://localhost:3000/api/students         (desarrollo)
    //   http://<ip-instancia-1>:3000/api/students   (AWS)
    //
    // Se entrega un valor por defecto como segundo argumento de
    // .get() para que TypeScript garantice que el resultado siempre
    // es "string" (nunca "undefined"), aunque la variable no esté
    // definida en el .env.
    private get classOperationsUrl(): string {
        return this.config.get<string>(
            'CLASS_OPERATIONS_API_URL',
            'http://localhost:3000/api/students',
        );
    }

    // ── Regla de negocio 1: promedio individual ────────────────────────────
    //
    //   GET /api/students/:id/average
    //
    // Pasos:
    //   1. Pide el estudiante a class-operations: GET /api/students/:id
    //   2. Si no existe (404), responde 404 también.
    //   3. Calcula el promedio sobre los datos recibidos.
    async getAverage(id: string) {
        const student = await this.fetchStudentById(id);
        if (!student) {
            throw new NotFoundException('Student not found.');
        }

        const average = calculateAverage(student);
        return {
            studentId: student.id,
            fullName: student.fullName,
            average,
        };
    }

    // ── Regla de negocio 2: ranking de toda la lista ───────────────────────
    //
    //   GET /api/students/ranking
    //
    // Pasos:
    //   1. Pide TODOS los estudiantes a class-operations: GET /api/students
    //   2. Construye el ranking ordenado por promedio.
    async getRanking() {
        const students = await this.fetchAllStudents();
        return buildRanking(students);
    }

    // ── helpers: comunicación HTTP con class-operations ────────────────────

    private async fetchStudentById(id: string): Promise<Student | null> {
        const url = `${this.classOperationsUrl}/${id}`;
        const response = await this.safeFetch(url);

        if (response.status === 404) {
            return null;
        }
        return response.json();
    }

    private async fetchAllStudents(): Promise<Student[]> {
        const response = await this.safeFetch(this.classOperationsUrl);
        return response.json();
    }

    // GUÍA: centraliza el manejo de errores de red / HTTP al llamar a
    // class-operations.
    //   - Si el servidor no responde (caída, URL incorrecta, etc.) ->
    //     503 Service Unavailable.
    //   - Si responde con un error distinto de 404 (ej. 500) ->
    //     502 Bad Gateway (el error "viene de otro servicio").
    //   - 404 se deja pasar para que cada método decida cómo manejarlo.
    private async safeFetch(url: string): Promise<Response> {
        let response: Response;

        try {
            response = await fetch(url);
        } catch (error) {
            throw new ServiceUnavailableException(
                `No se pudo conectar con class-operations en ${url}: ${error.message}`,
            );
        }

        if (!response.ok && response.status !== 404) {
            throw new BadGatewayException(
                `class-operations respondió con estado ${response.status}`,
            );
        }

        return response;
    }
}
