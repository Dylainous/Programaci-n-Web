// ============================================================
// GUÍA GENERAL DE ESTE ARCHIVO (students.calculations.ts)
//
// Aquí van las REGLAS DE NEGOCIO (cálculos), separadas del resto del
// código. Son funciones PURAS: no llaman a la base de datos, no hacen
// peticiones HTTP, solo reciben datos y devuelven un resultado.
//
// Esto es EXACTAMENTE el mismo patrón que en la plantilla Express
// anterior (calculateAverage / buildRanking dentro de
// routes/studentRoutes.js), solo que aquí viven en su propio archivo
// porque esta instancia (business-logic) no tiene controller "CRUD":
// su trabajo es PURO cálculo sobre datos obtenidos de otra API.
//
// CÓMO ADAPTAR A TU TEMA:
//   - Cambia la interfaz "Student" por los campos de tu entidad
//     (deben coincidir con el JSON que devuelve class-operations).
//   - Reescribe calculateAverage() con la fórmula que pida el examen
//     (ej. precio final con descuento, IMC, ingresos, etc.).
//   - Reescribe buildRanking() con el criterio de orden que corresponda
//     (de mayor a menor, de menor a mayor, filtrando algún subconjunto, etc.)
// ============================================================

// Forma del objeto Student tal como lo devuelve class-operations
// (ver class-operations/src/students/students.service.ts -> toResponse).
export interface Student {
    id: number;
    fullName: string;
    career: string;
    grade1: number;
    grade2: number;
    grade3: number;
    enrolledAt: string;
}

// Objeto de salida para el ranking (equivalente a "MoviePerformance" en
// la plantilla de películas, o "StudentPerformance" en la plantilla
// Express anterior).
export interface StudentPerformance {
    fullName: string;
    average: number;
    ranking: number;
}

// ── Regla de negocio 1: cálculo sobre UN registro ──────────────────────────
//
// promedio = (grade1 + grade2 + grade3) / 3
export const calculateAverage = (
    student: Pick<Student, 'grade1' | 'grade2' | 'grade3'>,
): number => {
    const sum = student.grade1 + student.grade2 + student.grade3;
    return parseFloat((sum / 3).toFixed(2));
};

// ── Regla de negocio 2: cálculo sobre TODA la lista (ranking) ──────────────
//
// 1. Calcula el promedio de cada estudiante (reutilizando calculateAverage).
// 2. Ordena de mayor a menor promedio.
// 3. Asigna la posición (ranking) según el orden resultante.
export const buildRanking = (students: Student[]): StudentPerformance[] => {
    return students
        .map((student) => ({
            fullName: student.fullName,
            average: calculateAverage(student),
        }))
        .sort((a, b) => b.average - a.average)
        .map((entry, index) => ({ ...entry, ranking: index + 1 }));
};
