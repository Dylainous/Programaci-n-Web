# class-operations (Instancia 1 — AWS)

API REST de **CRUD puro** ("Class Operations") sobre la entidad de
ejemplo `Student`. NestJS + Prisma (ORM) + Supabase PostgreSQL.

> Esta instancia NO tiene reglas de negocio (promedio, ranking, etc.).
> Esas viven en la otra instancia: **`business-logic`**, que CONSUME
> los endpoints de esta API por HTTP. Ver `GUIA_EXAMEN.md` en la raíz
> del proyecto para la explicación completa de la arquitectura.

---

## Estructura

```
class-operations/
├── prisma/
│   ├── schema.prisma     # Modelos (= tablas)
│   └── seed.sql          # Datos de prueba
├── scripts/
│   └── with-database-url.js   # Construye DATABASE_URL desde .env
├── src/
│   ├── prisma/
│   │   ├── prisma.module.ts
│   │   └── prisma.service.ts
│   ├── students/
│   │   ├── dto/
│   │   │   ├── create-student.dto.ts
│   │   │   └── update-student.dto.ts
│   │   ├── students.controller.ts
│   │   ├── students.module.ts
│   │   └── students.service.ts
│   ├── app.module.ts
│   └── main.ts
├── .env.example
└── package.json
```

---

## 1. Variables de entorno

```bash
cp .env.example .env
```

Completa con los datos de **Supabase → Project Settings → Database →
Connection string (Transaction pooler)**:

```
DB_HOST=aws-0-us-east-1.pooler.supabase.com
DB_PORT=6543
DB_NAME=postgres
DB_USER=postgres.[tu-project-ref]
DB_PASSWORD=[tu-password]
PORT=3000
```

> No necesitas escribir `DATABASE_URL`: el script
> `scripts/with-database-url.js` la construye automáticamente a partir
> de las variables anteriores antes de ejecutar Prisma o el servidor.
> Detalles en `GUIA_EXAMEN.md`.

## 2. Instalar dependencias y crear la base de datos

```bash
npm install
npm run prisma:generate   # genera el cliente de Prisma
npm run prisma:push       # crea la tabla "students" en Supabase
```

Luego, en el **SQL Editor de Supabase**, ejecuta `prisma/seed.sql` para
insertar datos de prueba.

## 3. Ejecutar

```bash
npm run dev     # desarrollo (watch mode)
npm start       # producción (requiere "npm run build" antes)
```

---

## Endpoints (CRUD)

| Método | URI | Descripción | Éxito | Errores |
|--------|-----|-------------|-------|---------|
| `POST`   | `/api/students` | Registrar estudiante | `201` | `400` |
| `GET`    | `/api/students` | Listar todos | `200` | `500` |
| `GET`    | `/api/students/:id` | Obtener uno | `200` | `404` |
| `PUT`    | `/api/students/:id` | Actualizar (reemplazo completo) | `200` | `400`, `404` |
| `DELETE` | `/api/students/:id` | Eliminar | `200` | `404` |

### Ejemplo POST `/api/students`
```json
{
    "fullName": "Ana Torres",
    "career": "Software Engineering",
    "grade1": 8.5,
    "grade2": 9.0,
    "grade3": 7.8
}
```
