-- ============================================================
-- Datos de prueba para la tabla "students"
--
-- GUÍA: Prisma (con "npm run prisma:push") crea la TABLA según
-- prisma/schema.prisma, pero NO inserta datos de prueba. Ejecuta
-- este script en el SQL Editor de Supabase DESPUÉS de hacer
-- "prisma:push", para tener datos con los que probar:
--   - GET /api/students            (listar)
--   - GET /api/students/:id        (obtener uno)
--   - PUT / DELETE /api/students/:id
--   - Los endpoints de la instancia "business-logic"
--     (promedio individual y ranking)
-- ============================================================

INSERT INTO students (full_name, career, grade_1, grade_2, grade_3) VALUES
    ('Ana Torres',        'Software Engineering', 8.50, 9.00, 7.80),
    ('Luis Pérez',        'Software Engineering', 6.00, 7.50, 6.50),
    ('María Fernández',   'Mechatronics',         9.20, 9.50, 9.00),
    ('Carlos Vega',       'Mechatronics',         5.00, 6.00, 5.50),
    ('Sofía Ramírez',     'Industrial Design',    7.00, 7.20, 8.00),
    ('Diego Castillo',    'Software Engineering', 10.00, 9.80, 9.90),
    ('Valeria Morales',   'Industrial Design',    6.50, 6.00, 7.00);
