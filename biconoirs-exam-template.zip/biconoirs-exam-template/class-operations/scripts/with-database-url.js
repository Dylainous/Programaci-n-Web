#!/usr/bin/env node

// ============================================================
// GUÍA: ¿Por qué existe este script?
//
// Prisma SIEMPRE necesita una variable llamada DATABASE_URL con el
// formato de cadena de conexión:
//   postgresql://usuario:password@host:puerto/basededatos
//
// Sin embargo, en esta plantilla el archivo .env usa el MISMO formato
// "por piezas" que ya usas en tus proyectos Express/pg:
//   DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
//
// Este script es un "envoltorio" (wrapper):
//   1. Carga las variables del archivo .env.
//   2. Construye DATABASE_URL a partir de esas piezas (solo si no
//      fue definida explícitamente).
//   3. Ejecuta el comando real (prisma db push, nest start, etc.)
//      pasándole DATABASE_URL ya construida en su entorno.
//
// De esta forma, NUNCA necesitas escribir DATABASE_URL a mano y
// puedes seguir usando el .env con el formato DB_HOST/DB_PORT/etc.
//
// USO (ver package.json -> "scripts"):
//   node scripts/with-database-url.js prisma db push
//   node scripts/with-database-url.js nest start --watch
//   node scripts/with-database-url.js node dist/main
// ============================================================

const path = require('path');
const { spawnSync } = require('child_process');

// Carga el .env ubicado en la raíz del proyecto.
// dotenv NO sobrescribe variables que ya existan en process.env,
// por eso en AWS (donde las variables se configuran directamente
// en el entorno, sin archivo .env) este "config()" simplemente no
// encuentra el archivo y no afecta nada.
require('dotenv').config({ path: path.resolve(__dirname, '..', '.env') });

const {
    DB_HOST,
    DB_PORT,
    DB_NAME,
    DB_USER,
    DB_PASSWORD,
    DATABASE_URL,
} = process.env;

// Si alguien ya definió DATABASE_URL manualmente, se respeta tal cual.
// Si no, se construye a partir de las piezas individuales.
const databaseUrl = DATABASE_URL
    || `postgresql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}?pgbouncer=true`;

const [command, ...args] = process.argv.slice(2);

if (!command) {
    console.error('Uso: node scripts/with-database-url.js <comando> [argumentos...]');
    process.exit(1);
}

const result = spawnSync(command, args, {
    stdio: 'inherit',
    shell: true,
    env: { ...process.env, DATABASE_URL: databaseUrl },
});

process.exit(result.status === null ? 1 : result.status);
