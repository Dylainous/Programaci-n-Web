import { CreateStudentDto } from './create-student.dto';

// ============================================================
// GUÍA: PUT vs PATCH
//
// PUT = reemplazo COMPLETO del recurso. El cliente debe enviar TODOS
// los campos editables, igual que en POST. Por eso UpdateStudentDto
// simplemente EXTIENDE (hereda) todas las reglas de CreateStudentDto,
// sin agregar ni quitar nada.
//
// Si el examen pidiera una actualización PARCIAL (PATCH), usarías:
//
//   import { PartialType } from '@nestjs/mapped-types';
//   export class UpdateStudentDto extends PartialType(CreateStudentDto) {}
//
// "PartialType" convierte todos los campos en OPCIONALES, pero si
// vienen, se validan igual que en el DTO original.
// ============================================================

export class UpdateStudentDto extends CreateStudentDto {}
