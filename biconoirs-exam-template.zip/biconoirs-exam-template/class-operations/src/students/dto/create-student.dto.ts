import { IsString, IsNotEmpty, IsNumber, Min, Max } from 'class-validator';

// ============================================================
// GUÍA GENERAL DE LOS DTO (Data Transfer Object)
//
// En el proyecto con Express+pg, las validaciones se escribían a mano
// dentro de la ruta (validateStudentBody). En NestJS + ORM, esas
// validaciones se declaran como DECORADORES sobre cada campo del DTO,
// usando la librería "class-validator". Nest las ejecuta
// automáticamente gracias al ValidationPipe global (ver src/main.ts).
//
// Tabla de equivalencias rápida:
//   Validación manual (Express)                  -> Decorador (Nest)
//   typeof x === 'string' && x.trim() !== ''     -> @IsString() @IsNotEmpty()
//   typeof x === 'number'                        -> @IsNumber()
//   Number.isInteger(x)                          -> @IsInt()
//   x > 0                                        -> @IsPositive()  o  @Min(0.01)
//   x >= 0                                       -> @Min(0)
//   x dentro de un rango [0,10]                  -> @Min(0) @Max(10)
//
// Si el campo es opcional, agrega @IsOptional() ANTES de las demás
// reglas (si no viene, las demás reglas no se evalúan).
//
// CÓMO ADAPTAR: cambia los nombres de los campos y las reglas según
// la entidad y los requisitos del examen.
// ============================================================

export class CreateStudentDto {
    @IsString()
    @IsNotEmpty()
    fullName: string;

    @IsString()
    @IsNotEmpty()
    career: string;

    // GUÍA: ejemplo de "número dentro de un rango" (nota entre 0 y 10).
    @IsNumber()
    @Min(0)
    @Max(10)
    grade1: number;

    @IsNumber()
    @Min(0)
    @Max(10)
    grade2: number;

    @IsNumber()
    @Min(0)
    @Max(10)
    grade3: number;
}
