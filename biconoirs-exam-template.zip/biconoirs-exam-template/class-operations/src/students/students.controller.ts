import {
    Controller,
    Get,
    Post,
    Put,
    Delete,
    Param,
    Body,
    HttpCode,
    HttpStatus,
    NotFoundException,
    ParseIntPipe,
} from '@nestjs/common';
import { StudentsService } from './students.service';
import { CreateStudentDto } from './dto/create-student.dto';
import { UpdateStudentDto } from './dto/update-student.dto';

// ============================================================
// GUÍA GENERAL DE ESTE ARCHIVO (students.controller.ts)
//
// Es el equivalente a routes/studentRoutes.js de la plantilla
// Express, pero con DECORADORES en vez de router.get/post/...
//
// Esta INSTANCIA (class-operations) SOLO implementa CRUD puro:
//   POST   /api/students
//   GET    /api/students
//   GET    /api/students/:id
//   PUT    /api/students/:id
//   DELETE /api/students/:id
//
// Las reglas de negocio (promedio, ranking) NO van aquí: van en la
// otra instancia ("business-logic"), que CONSUME estos endpoints
// por HTTP. Ver business-logic/src/students/students.service.ts.
//
// NOTA SOBRE EL ORDEN DE RUTAS:
// En la plantilla Express anterior había que tener cuidado con el
// orden ("/ranking" antes de "/:id"). En esta instancia eso NO aplica
// porque aquí NO hay rutas con texto fijo del tipo "/ranking" o
// "/:id/average": son solo las 5 operaciones CRUD estándar.
// ============================================================

@Controller('api/students')
export class StudentsController {
    constructor(private readonly studentsService: StudentsService) {}

    // ───────────────────────────────────────────────────────────────────
    // GET /api/students   (Read - listar todos)
    //
    //   Método:  GET
    //   URI:     /api/students
    //   Request: sin body
    //   Response (200): arreglo de objetos Student
    // ───────────────────────────────────────────────────────────────────
    @Get()
    findAll() {
        return this.studentsService.findAll();
    }

    // ───────────────────────────────────────────────────────────────────
    // GET /api/students/:id   (Read - obtener uno)
    //
    //   Método:  GET
    //   URI:     /api/students/:id
    //   Request: sin body
    //   Response (200): objeto Student
    //   Errores:  404 si no existe un estudiante con ese id
    //
    // GUÍA: "ParseIntPipe" convierte automáticamente el parámetro de
    // ruta (string) a number, y responde 400 si no es un número
    // válido (ej. /api/students/abc).
    // ───────────────────────────────────────────────────────────────────
    @Get(':id')
    async findOne(@Param('id', ParseIntPipe) id: number) {
        const student = await this.studentsService.findOne(id);
        if (!student) {
            throw new NotFoundException('Student not found.');
        }
        return student;
    }

    // ───────────────────────────────────────────────────────────────────
    // POST /api/students   (Create - registrar)
    //
    //   Método:  POST
    //   URI:     /api/students
    //   Request body:
    //     {
    //       "fullName": "Ana Torres",
    //       "career": "Software Engineering",
    //       "grade1": 8.5,
    //       "grade2": 9.0,
    //       "grade3": 7.8
    //     }
    //   Response (201): objeto Student creado (incluye "id" y "enrolledAt")
    //   Errores: 400 si el body no pasa las validaciones del DTO
    //
    // GUÍA: el código 201 normalmente se pone con @HttpCode(201) o
    // con el decorador @HttpCode(HttpStatus.CREATED). Nest usa 201
    // por defecto en POST, pero lo dejamos explícito para que sea
    // más claro durante el examen.
    // ───────────────────────────────────────────────────────────────────
    @Post()
    @HttpCode(HttpStatus.CREATED)
    create(@Body() dto: CreateStudentDto) {
        return this.studentsService.create(dto);
    }

    // ───────────────────────────────────────────────────────────────────
    // PUT /api/students/:id   (Update - reemplazar)
    //
    //   Método:  PUT
    //   URI:     /api/students/:id
    //   Request body: igual que POST (reemplazo completo)
    //   Response (200): objeto Student actualizado
    //   Errores:
    //     - 400 si el body no pasa las validaciones del DTO
    //     - 404 si no existe un estudiante con ese id
    // ───────────────────────────────────────────────────────────────────
    @Put(':id')
    async update(
        @Param('id', ParseIntPipe) id: number,
        @Body() dto: UpdateStudentDto,
    ) {
        const updated = await this.studentsService.update(id, dto);
        if (!updated) {
            throw new NotFoundException('Student not found.');
        }
        return updated;
    }

    // ───────────────────────────────────────────────────────────────────
    // DELETE /api/students/:id   (Delete - eliminar)
    //
    //   Método:  DELETE
    //   URI:     /api/students/:id
    //   Request: sin body
    //   Response (200): mensaje de confirmación
    //   Errores: 404 si no existe un estudiante con ese id
    //
    // GUÍA: si el examen exige 204 (No Content), cambia el decorador a
    // @HttpCode(HttpStatus.NO_CONTENT) y haz que el método no retorne
    // contenido (return;).
    // ───────────────────────────────────────────────────────────────────
    @Delete(':id')
    async remove(@Param('id', ParseIntPipe) id: number) {
        const deleted = await this.studentsService.remove(id);
        if (!deleted) {
            throw new NotFoundException('Student not found.');
        }
        return { message: 'Student deleted successfully.' };
    }
}
