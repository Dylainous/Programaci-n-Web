import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateStudentDto } from './dto/create-student.dto';
import { UpdateStudentDto } from './dto/update-student.dto';

// ============================================================
// GUÍA GENERAL DE ESTE ARCHIVO (students.service.ts)
//
// Aquí va TODA la comunicación con la base de datos, igual que en
// models/student.js de la plantilla anterior, pero usando Prisma
// en vez de SQL escrito a mano.
//
// Equivalencias con la plantilla SQL anterior:
//   findAll()  -> prisma.student.findMany()
//   findById() -> prisma.student.findUnique({ where: { id } })
//   create()   -> prisma.student.create({ data })
//   update()   -> prisma.student.update({ where: { id }, data })
//   remove()   -> prisma.student.delete({ where: { id } })
//
// CÓMO ADAPTAR A TU TEMA:
//   1. Cambia "this.prisma.student" por "this.prisma.<tuModelo>"
//      (el nombre va en minúscula, aunque el modelo en schema.prisma
//      esté en PascalCase: "Product" -> "this.prisma.product").
//   2. Ajusta toResponse() según los campos de tu entidad.
//   3. Mantén la forma de las 5 funciones (findAll, findById, create,
//      update, remove): así no tienes que rediseñar el controller.
// ============================================================

@Injectable()
export class StudentsService {
    constructor(private readonly prisma: PrismaService) {}

    // ── READ ───────────────────────────────────────────────────────────────

    // GUÍA: soporta GET /api/students
    async findAll() {
        const students = await this.prisma.student.findMany({
            orderBy: { id: 'asc' },
        });
        return students.map(this.toResponse);
    }

    // GUÍA: soporta GET /api/students/:id
    // Retorna null si no existe -> el controller responde 404.
    async findOne(id: number) {
        const student = await this.prisma.student.findUnique({ where: { id } });
        return student ? this.toResponse(student) : null;
    }

    // ── CREATE ─────────────────────────────────────────────────────────────

    // GUÍA: soporta POST /api/students
    // "dto" ya llegó validado por el ValidationPipe global (main.ts).
    async create(dto: CreateStudentDto) {
        const student = await this.prisma.student.create({ data: dto });
        return this.toResponse(student);
    }

    // ── UPDATE ─────────────────────────────────────────────────────────────

    // GUÍA: soporta PUT /api/students/:id
    // Prisma lanza un error con código "P2025" si el "id" no existe.
    // Lo capturamos y devolvemos null -> el controller responde 404.
    async update(id: number, dto: UpdateStudentDto) {
        try {
            const student = await this.prisma.student.update({
                where: { id },
                data: dto,
            });
            return this.toResponse(student);
        } catch (error) {
            if (error.code === 'P2025') {
                return null;
            }
            throw error;
        }
    }

    // ── DELETE ─────────────────────────────────────────────────────────────

    // GUÍA: soporta DELETE /api/students/:id
    // Mismo manejo de "P2025" que en update().
    async remove(id: number) {
        try {
            await this.prisma.student.delete({ where: { id } });
            return true;
        } catch (error) {
            if (error.code === 'P2025') {
                return false;
            }
            throw error;
        }
    }

    // ── helpers ────────────────────────────────────────────────────────────

    // GUÍA: Prisma devuelve los campos "Decimal" como objetos Decimal
    // (de la librería decimal.js), no como "number" de JavaScript.
    // Number(...) los convierte a número plano para que el JSON de
    // respuesta sea limpio (ej. 8.5 en vez de "8.5" o un objeto).
    private toResponse(student: {
        id: number;
        fullName: string;
        career: string;
        grade1: any;
        grade2: any;
        grade3: any;
        enrolledAt: Date;
    }) {
        return {
            id: student.id,
            fullName: student.fullName,
            career: student.career,
            grade1: Number(student.grade1),
            grade2: Number(student.grade2),
            grade3: Number(student.grade3),
            enrolledAt: student.enrolledAt,
        };
    }
}
