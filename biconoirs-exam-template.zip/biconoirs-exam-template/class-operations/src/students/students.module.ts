import { Module } from '@nestjs/common';
import { StudentsController } from './students.controller';
import { StudentsService } from './students.service';

// GUÍA: PrismaService NO se importa aquí porque PrismaModule es
// @Global() (ver src/prisma/prisma.module.ts) y ya está disponible
// en toda la aplicación una vez registrado en AppModule.
@Module({
    controllers: [StudentsController],
    providers: [StudentsService],
})
export class StudentsModule {}
