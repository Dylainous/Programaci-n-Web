import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { StudentsModule } from './students/students.module';

// ============================================================
// GUÍA: Este es el "punto central" donde se registran todos los
// módulos de la aplicación.
//
// CÓMO AGREGAR UNA NUEVA ENTIDAD (ej. "courses" además de "students"):
//   1. Crea src/courses/ con su .controller.ts, .service.ts,
//      .module.ts y dto/ (copiando la estructura de students/).
//   2. Importa CoursesModule aquí, dentro de "imports".
//
// ConfigModule.forRoot() carga el archivo .env y permite usar
// process.env.PORT, process.env.DB_HOST, etc. en cualquier parte
// de la aplicación.
// ============================================================

@Module({
    imports: [
        ConfigModule.forRoot({ isGlobal: true }),
        PrismaModule,
        StudentsModule,
    ],
})
export class AppModule {}
