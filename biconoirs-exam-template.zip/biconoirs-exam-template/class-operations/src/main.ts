import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';

// ============================================================
// GUÍA: Punto de entrada de la INSTANCIA 1 (class-operations).
//
// - ValidationPipe global: hace que TODOS los DTOs (CreateStudentDto,
//   UpdateStudentDto, etc.) se validen automáticamente. Si algún
//   campo no cumple las reglas (@IsString, @Min, @Max, etc.), Nest
//   responde automáticamente con HTTP 400 y el detalle de los
//   errores - NO necesitas escribir ese "if (errors.length > 0)"
//   a mano como en la plantilla Express.
//
//     whitelist: true   -> elimina del body cualquier campo que NO
//                           esté declarado en el DTO (evita inyectar
//                           campos extra no deseados).
//     transform: true   -> convierte tipos automáticamente (ej. los
//                           query params/strings a number si el DTO
//                           espera @IsNumber()).
//
// - process.env.PORT || 3000: igual que en la plantilla Express,
//   deja el proyecto listo para AWS (Elastic Beanstalk inyecta PORT).
// ============================================================

async function bootstrap() {
    const app = await NestFactory.create(AppModule);

    app.useGlobalPipes(
        new ValidationPipe({
            whitelist: true,
            transform: true,
        }),
    );

    const port = process.env.PORT || 3000;
    await app.listen(port);
    console.log(`Class Operations API is running on port --> ${port}`);
}
bootstrap();
