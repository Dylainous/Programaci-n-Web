import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

// GUÍA: Este módulo es @Global(), igual que en el proyecto Biconoirs
// original. Esto significa que PrismaService está disponible para
// inyectar en CUALQUIER otro módulo sin tener que importar
// PrismaModule explícitamente en cada uno.
@Global()
@Module({
    providers: [PrismaService],
    exports: [PrismaService],
})
export class PrismaModule {}
