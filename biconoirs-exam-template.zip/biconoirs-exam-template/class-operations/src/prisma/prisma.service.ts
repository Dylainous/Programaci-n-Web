import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

// GUÍA: Este archivo NO cambia entre proyectos. Es exactamente igual
// al de tu proyecto Biconoirs original: conecta Prisma a la base de
// datos cuando arranca el módulo, y desconecta cuando se apaga.
@Injectable()
export class PrismaService
    extends PrismaClient
    implements OnModuleInit, OnModuleDestroy
{
    async onModuleInit() {
        await this.$connect();
    }

    async onModuleDestroy() {
        await this.$disconnect();
    }
}
