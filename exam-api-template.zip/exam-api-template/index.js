require('dotenv').config();

const express = require('express');
const pool    = require('./config/db');

const app  = express();
const port = process.env.PORT || 3000;

// ── middleware ─────────────────────────────────────────────────────────────
// GUÍA: express.json() permite leer req.body en formato JSON.
// Es OBLIGATORIO para que POST y PUT funcionen.
app.use(express.json());

// ── verify DB connection on startup ───────────────────────────────────────
pool.query('SELECT NOW()', (err) => {
    if (err) {
        console.error('Failed to connect to database:', err.message);
        process.exit(1);
    }
    console.log('System connected to Supabase PostgreSQL Database');
});

// ── routes ─────────────────────────────────────────────────────────────────
// GUÍA: Para agregar más entidades en el examen (ej. el proyecto pide
// "students" Y "courses"), repite este patrón:
//
//   const courseRouter = require('./routes/courseRoutes');
//   app.use('/api/courses', courseRouter);
//
// Cada entidad tiene su propio archivo de modelo y de rutas.
const studentRouter = require('./routes/studentRoutes');
app.use('/api/students', studentRouter);

// ── start server ───────────────────────────────────────────────────────────
// GUÍA: process.env.PORT || 3000 deja el proyecto listo para AWS
// (Elastic Beanstalk inyecta PORT automáticamente).
app.listen(port, () => {
    console.log(`API Server is running on port --> ${port}`);
});
