-- ============================================================
-- EJEMPLO DE ENTIDAD: students
--
-- GUÍA: Esta tabla es solo un EJEMPLO de cómo estructurar la
-- entidad principal del examen. Para adaptarla a tu tema:
--
--   1. Cambia el nombre de la tabla (ej. "products", "books",
--      "employees", "vehicles", etc.)
--   2. Cambia las columnas según los atributos que te pidan.
--   3. Mantén SIEMPRE:
--        - "id"          → SERIAL PRIMARY KEY (clave única)
--        - "created_at"  → TIMESTAMPTZ DEFAULT NOW() (fecha de registro)
--   4. Agrega restricciones CHECK para validar reglas como:
--        - valores mayores a 0
--        - rangos permitidos (ej. notas entre 0 y 10)
--        - valores no negativos
--
-- En este ejemplo: un estudiante con 3 notas (parciales), usadas
-- después para calcular un PROMEDIO (regla de negocio 1) y un
-- RANKING de mejores promedios (regla de negocio 2).
-- ============================================================

CREATE TABLE IF NOT EXISTS students (
    id           SERIAL PRIMARY KEY,
    full_name    VARCHAR(255)   NOT NULL,
    career       VARCHAR(150)   NOT NULL,
    grade_1      NUMERIC(4,2)   NOT NULL CHECK (grade_1 BETWEEN 0 AND 10),
    grade_2      NUMERIC(4,2)   NOT NULL CHECK (grade_2 BETWEEN 0 AND 10),
    grade_3      NUMERIC(4,2)   NOT NULL CHECK (grade_3 BETWEEN 0 AND 10),
    enrolled_at  TIMESTAMPTZ    NOT NULL DEFAULT NOW()
);
