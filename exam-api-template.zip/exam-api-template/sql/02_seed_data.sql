-- ============================================================
-- Datos de prueba para la tabla students
--
-- GUÍA: Siempre incluye datos de prueba suficientes para validar:
--   - El listado general (GET all)
--   - La búsqueda por id (GET by id)
--   - Los cálculos de las reglas de negocio (promedio, ranking)
--   - Los casos de actualización y eliminación (PUT / DELETE)
-- ============================================================

INSERT INTO students (full_name, career, grade_1, grade_2, grade_3) VALUES
    ('Ana Torres',        'Software Engineering', 8.50, 9.00, 7.80),
    ('Luis Pérez',        'Software Engineering', 6.00, 7.50, 6.50),
    ('María Fernández',   'Mechatronics',         9.20, 9.50, 9.00),
    ('Carlos Vega',       'Mechatronics',         5.00, 6.00, 5.50),
    ('Sofía Ramírez',     'Industrial Design',    7.00, 7.20, 8.00),
    ('Diego Castillo',    'Software Engineering', 10.00, 9.80, 9.90),
    ('Valeria Morales',   'Industrial Design',    6.50, 6.00, 7.00);
