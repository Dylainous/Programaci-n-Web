const pool = require('../config/db');

// ─────────────────────────────────────────────────────────────────────────
// GUÍA GENERAL DE ESTE ARCHIVO (models/<entidad>.js)
//
// Aquí va TODA la comunicación directa con la base de datos (SQL puro,
// sin ORM). Las rutas (routes/) NUNCA deben escribir SQL directamente:
// siempre llaman a una función de este archivo.
//
// Para adaptar este archivo a un nuevo tema:
//   1. Cambia el nombre de la tabla en cada query ("students" → la tuya).
//   2. Ajusta las columnas dentro de toMovie/toEntity y en los INSERT/UPDATE.
//   3. Mantén la misma forma de las 5 funciones: findAll, findById,
//      create, update, remove. Esa estructura cubre TODO el CRUD.
// ─────────────────────────────────────────────────────────────────────────

// ── helpers ────────────────────────────────────────────────────────────────

/**
 * Convierte una fila cruda de la base de datos (snake_case) al formato
 * de la entidad usada en las respuestas JSON (camelCase).
 *
 * GUÍA: Renombra los campos según tu entidad. El patrón es siempre:
 *   columna_de_la_bd  →  campoEnCamelCase
 */
const toStudent = (row) => ({
    id:         row.id,
    fullName:   row.full_name,
    career:     row.career,
    grade1:     parseFloat(row.grade_1),
    grade2:     parseFloat(row.grade_2),
    grade3:     parseFloat(row.grade_3),
    enrolledAt: row.enrolled_at
});

// ── READ ─────────────────────────────────────────────────────────────────

// GUÍA: findAll() soporta el endpoint GET /api/students
const findAll = async () => {
    const result = await pool.query(
        'SELECT * FROM students ORDER BY id ASC'
    );
    return result.rows.map(toStudent);
};

// GUÍA: findById() soporta GET /api/students/:id
// Devuelve null si no existe -> la ruta lo convierte en HTTP 404.
const findById = async (id) => {
    const result = await pool.query(
        'SELECT * FROM students WHERE id = $1',
        [id]
    );
    return result.rows.length ? toStudent(result.rows[0]) : null;
};

// ── CREATE ───────────────────────────────────────────────────────────────

// GUÍA: create() soporta POST /api/students
// Recibe un objeto ya validado (ver routes/) y lo inserta.
// "RETURNING *" devuelve la fila completa, incluyendo id y created_at.
const create = async ({ fullName, career, grade1, grade2, grade3 }) => {
    const result = await pool.query(
        `INSERT INTO students (full_name, career, grade_1, grade_2, grade_3)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING *`,
        [fullName, career, grade1, grade2, grade3]
    );
    return toStudent(result.rows[0]);
};

// ── UPDATE ───────────────────────────────────────────────────────────────

// GUÍA: update() soporta PUT /api/students/:id
// Este ejemplo hace un reemplazo COMPLETO de los campos (PUT clásico):
// el cliente debe enviar TODOS los campos editables en el body.
// Si no existe ninguna fila con ese id, retorna null -> la ruta
// responde HTTP 404.
const update = async (id, { fullName, career, grade1, grade2, grade3 }) => {
    const result = await pool.query(
        `UPDATE students
            SET full_name = $1,
                career     = $2,
                grade_1    = $3,
                grade_2    = $4,
                grade_3    = $5
          WHERE id = $6
          RETURNING *`,
        [fullName, career, grade1, grade2, grade3, id]
    );
    return result.rows.length ? toStudent(result.rows[0]) : null;
};

// ── DELETE ───────────────────────────────────────────────────────────────

// GUÍA: remove() soporta DELETE /api/students/:id
// "RETURNING id" nos permite saber si realmente existía una fila con
// ese id (rowCount === 0 -> no existía -> la ruta responde HTTP 404).
const remove = async (id) => {
    const result = await pool.query(
        'DELETE FROM students WHERE id = $1 RETURNING id',
        [id]
    );
    return result.rowCount > 0;
};

module.exports = { findAll, findById, create, update, remove };
