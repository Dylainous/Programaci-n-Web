const express = require('express');
const Student = require('../models/student');
const router  = express.Router();

// ─────────────────────────────────────────────────────────────────────────
// GUÍA GENERAL DE ESTE ARCHIVO (routes/<entidad>Routes.js)
//
// Aquí van TRES cosas, en este orden:
//   1. VALIDACIONES   -> función validateBody()
//   2. REGLAS DE NEGOCIO (cálculos) -> funciones puras, sin tocar la BD
//   3. ENDPOINTS       -> router.get/post/put/delete
//
// ORDEN DE LAS RUTAS: Express evalúa las rutas de arriba hacia abajo.
// Cualquier ruta GET con un texto fijo (ej. "/ranking") DEBE declararse
// ANTES que "/:id" o GET "/:id/promedio", porque si no, Express
// interpretará "ranking" como si fuera un :id.
// ─────────────────────────────────────────────────────────────────────────


// ── 1. VALIDACIONES ─────────────────────────────────────────────────────

// GUÍA: Esta función valida el body de POST y PUT (en este ejemplo ambos
// usan los mismos campos). Si tu PUT permite actualizar menos campos que
// el POST, crea una segunda función (ej. validateUpdateBody).
//
// Reglas típicas que el examen suele pedir:
//   - campo obligatorio (string no vacío)
//   - campo numérico
//   - campo numérico mayor que 0 / mayor o igual a 0 / dentro de un rango
//   - campo entero
//
// Cada regla agrega un mensaje a "errors". Si "errors" tiene elementos,
// la ruta responde HTTP 400 con la lista completa (así el usuario ve
// todos los problemas de una vez, no uno por uno).
const validateStudentBody = (body) => {
    const errors = [];

    if (!body.fullName || typeof body.fullName !== 'string' || body.fullName.trim() === '') {
        errors.push('fullName is required.');
    }
    if (!body.career || typeof body.career !== 'string' || body.career.trim() === '') {
        errors.push('career is required.');
    }

    // GUÍA: patrón para validar un número dentro de un rango (0 a 10).
    // Cambia el rango/condición según lo que pida tu examen
    // (ej. "mayor que 0", "mayor o igual a 0", "entre 1 y 100", etc.)
    [['grade1', body.grade1], ['grade2', body.grade2], ['grade3', body.grade3]]
        .forEach(([fieldName, value]) => {
            if (typeof value !== 'number' || value < 0 || value > 10) {
                errors.push(`${fieldName} must be a number between 0 and 10.`);
            }
        });

    return errors;
};


// ── 2. REGLAS DE NEGOCIO (CÁLCULOS) ─────────────────────────────────────

// GUÍA: PATRÓN GENERAL PARA "CÁLCULO SOBRE UN SOLO REGISTRO"
// (ej. promedio de un alumno, ingresos de una película, total de una
// factura, IMC de una persona, etc.)
//
//   - Es una función PURA: recibe el objeto y devuelve un número/objeto,
//     SIN consultar la base de datos.
//   - NUNCA se guarda en la tabla (no se crea una columna "average").
//   - Se calcula "al vuelo" cada vez que se solicita.
//
// En este ejemplo: promedio = (grade1 + grade2 + grade3) / 3
const calculateAverage = (student) => {
    const sum = student.grade1 + student.grade2 + student.grade3;
    return parseFloat((sum / 3).toFixed(2));
};

// GUÍA: PATRÓN GENERAL PARA "CÁLCULO SOBRE UNA LISTA" (ranking / resumen)
// (ej. ranking de mejores promedios, ranking de rentabilidad de películas,
// top de productos más vendidos, etc.)
//
//   1. Recorremos TODOS los registros (movies.map / students.map).
//   2. Calculamos el valor individual para cada uno (reutilizando la
//      función del punto anterior -> evita duplicar lógica).
//   3. Ordenamos el arreglo resultante (.sort) de mayor a menor (o al revés
//      según lo que pida el examen).
//   4. Asignamos la posición (ranking) recorriendo el arreglo YA ORDENADO
//      con .map((item, index) => ranking: index + 1).
//
// El objeto de salida (aquí "StudentPerformance") es DISTINTO al objeto
// "Student": solo contiene los campos relevantes para el resultado.
const buildRanking = (students) => {
    return students
        .map((student) => ({
            fullName: student.fullName,
            average:  calculateAverage(student)
        }))
        .sort((a, b) => b.average - a.average)
        .map((entry, index) => ({ ...entry, ranking: index + 1 }));
};


// ── 3. ENDPOINTS ─────────────────────────────────────────────────────────

// ───────────────────────────────────────────────────────────────────────
// GET /api/students/ranking   (Regla de negocio 2: ranking)
//
// GUÍA: Va PRIMERO porque "ranking" es texto fijo, no un :id.
// Caso de uso: "Devuelve la lista de estudiantes ordenada por promedio,
// de mayor a menor, indicando la posición de cada uno".
//
//   Método:  GET
//   URI:     /api/students/ranking
//   Request: sin body
//   Response (200):
//     [
//       { "fullName": "Diego Castillo", "average": 9.90, "ranking": 1 },
//       { "fullName": "María Fernández", "average": 9.23, "ranking": 2 }
//     ]
// ───────────────────────────────────────────────────────────────────────
router.get('/ranking', async (req, res) => {
    try {
        const students = await Student.findAll();
        const ranking  = buildRanking(students);
        res.status(200).json(ranking);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// ───────────────────────────────────────────────────────────────────────
// GET /api/students   (Read - listar todos)
//
// Caso de uso: "Obtener el listado completo de estudiantes registrados".
//
//   Método:  GET
//   URI:     /api/students
//   Request: sin body
//   Response (200): arreglo de objetos Student
//   Errores: 500 si falla la consulta a la base de datos
// ───────────────────────────────────────────────────────────────────────
router.get('/', async (req, res) => {
    try {
        const students = await Student.findAll();
        res.status(200).json(students);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// ───────────────────────────────────────────────────────────────────────
// POST /api/students   (Create - registrar)
//
// Caso de uso: "Registrar un nuevo estudiante con sus notas".
//
//   Método:  POST
//   URI:     /api/students
//   Request body:
//     {
//       "fullName": "Ana Torres",
//       "career": "Software Engineering",
//       "grade1": 8.5,
//       "grade2": 9.0,
//       "grade3": 7.8
//     }
//   Response (201): el objeto Student creado, incluyendo "id" y "enrolledAt"
//   Errores: 400 si falla alguna validación (ver validateStudentBody)
// ───────────────────────────────────────────────────────────────────────
router.post('/', async (req, res) => {
    const errors = validateStudentBody(req.body);
    if (errors.length > 0) {
        return res.status(400).json({ errors });
    }

    try {
        const student = await Student.create(req.body);
        res.status(201).json(student);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// ───────────────────────────────────────────────────────────────────────
// GET /api/students/:id/average   (Regla de negocio 1: cálculo individual)
//
// GUÍA: Va ANTES de GET /:id por la misma razón que "/ranking":
// "average" es texto fijo dentro de la ruta, no un parámetro.
//
// Caso de uso: "Calcular el promedio de notas de un estudiante específico".
//
//   Método:  GET
//   URI:     /api/students/:id/average
//   Request: sin body
//   Response (200):
//     { "studentId": 1, "fullName": "Ana Torres", "average": 8.43 }
//   Errores: 404 si el estudiante no existe
// ───────────────────────────────────────────────────────────────────────
router.get('/:id/average', async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        if (!student) {
            return res.status(404).json({ message: 'Student not found.' });
        }
        const average = calculateAverage(student);
        res.status(200).json({
            studentId: student.id,
            fullName:  student.fullName,
            average
        });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// ───────────────────────────────────────────────────────────────────────
// GET /api/students/:id   (Read - obtener uno)
//
// Caso de uso: "Obtener los datos de un estudiante específico mediante
// su identificador".
//
//   Método:  GET
//   URI:     /api/students/:id
//   Request: sin body
//   Response (200): objeto Student
//   Errores: 404 si no existe un estudiante con ese id
// ───────────────────────────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
    try {
        const student = await Student.findById(req.params.id);
        if (!student) {
            return res.status(404).json({ message: 'Student not found.' });
        }
        res.status(200).json(student);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// ───────────────────────────────────────────────────────────────────────
// PUT /api/students/:id   (Update - reemplazar)
//
// Caso de uso: "Actualizar los datos completos de un estudiante
// (todas las notas y datos personales)".
//
// GUÍA: PUT = reemplazo COMPLETO. El cliente debe enviar TODOS los
// campos (igual que en POST). Por eso reutilizamos la misma validación.
// Si el examen pide una actualización PARCIAL (solo algunos campos),
// se usaría PATCH en vez de PUT, y la validación sería distinta
// (cada campo es opcional, pero si viene, debe ser válido).
//
//   Método:  PUT
//   URI:     /api/students/:id
//   Request body: igual que POST
//   Response (200): objeto Student actualizado
//   Errores:
//     - 400 si el body no pasa las validaciones
//     - 404 si no existe un estudiante con ese id
// ───────────────────────────────────────────────────────────────────────
router.put('/:id', async (req, res) => {
    const errors = validateStudentBody(req.body);
    if (errors.length > 0) {
        return res.status(400).json({ errors });
    }

    try {
        const updatedStudent = await Student.update(req.params.id, req.body);
        if (!updatedStudent) {
            return res.status(404).json({ message: 'Student not found.' });
        }
        res.status(200).json(updatedStudent);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// ───────────────────────────────────────────────────────────────────────
// DELETE /api/students/:id   (Delete - eliminar)
//
// Caso de uso: "Eliminar el registro de un estudiante".
//
//   Método:  DELETE
//   URI:     /api/students/:id
//   Request: sin body
//   Response (200): mensaje de confirmación
//     { "message": "Student deleted successfully." }
//   Errores: 404 si no existe un estudiante con ese id
//
// GUÍA: Algunas guías de examen piden HTTP 204 (No Content) en vez de 200.
// Si te lo piden así, usa: res.status(204).send();  (sin body en la
// respuesta). Aquí se usa 200 con mensaje porque es más fácil de
// verificar visualmente en Postman/Thunder Client.
// ───────────────────────────────────────────────────────────────────────
router.delete('/:id', async (req, res) => {
    try {
        const deleted = await Student.remove(req.params.id);
        if (!deleted) {
            return res.status(404).json({ message: 'Student not found.' });
        }
        res.status(200).json({ message: 'Student deleted successfully.' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
