# exam-api-template

Plantilla reutilizable para examen: API REST con Node.js + Express + Supabase
(PostgreSQL), CRUD completo (GET, POST, PUT, DELETE) + reglas de negocio
(cálculos).

**El ejemplo incluido es "students"** (estudiantes con 3 notas, promedio y
ranking). Para el examen, lee primero **`GUIA_EXAMEN.md`** — ahí está
explicado paso a paso cómo adaptar esta plantilla a CUALQUIER tema que te
asignen.

---

## Estructura del proyecto

```
exam-api-template/
├── config/
│   └── db.js                 # Conexión a PostgreSQL (no cambia)
├── models/
│   └── student.js            # CRUD: findAll, findById, create, update, remove
├── routes/
│   └── studentRoutes.js       # Endpoints + validaciones + reglas de negocio
├── sql/
│   ├── 01_create_tables.sql
│   └── 02_seed_data.sql
├── .env.example
├── .gitignore
├── index.js
├── package.json
├── GUIA_EXAMEN.md             # ← Guía paso a paso para el examen
└── README.md
```

---

## 1. Base de datos (Supabase)

En el **SQL Editor** de Supabase, ejecuta en orden:
- `sql/01_create_tables.sql`
- `sql/02_seed_data.sql`

## 2. Variables de entorno

```bash
cp .env.example .env
```

Completa `.env` con los datos de **Supabase → Project Settings → Database →
Connection string (Transaction pooler)**.

## 3. Instalar y ejecutar

```bash
npm install
npm run dev     # desarrollo
npm start       # producción
```

---

## Endpoints del ejemplo (students)

| Método | URI | Descripción |
|--------|-----|-------------|
| `POST`   | `/api/students` | Registrar estudiante |
| `GET`    | `/api/students` | Listar todos |
| `GET`    | `/api/students/:id` | Obtener uno por id |
| `PUT`    | `/api/students/:id` | Actualizar (reemplazo completo) |
| `DELETE` | `/api/students/:id` | Eliminar |
| `GET`    | `/api/students/:id/average` | Regla 1: promedio individual |
| `GET`    | `/api/students/ranking` | Regla 2: ranking por promedio |
