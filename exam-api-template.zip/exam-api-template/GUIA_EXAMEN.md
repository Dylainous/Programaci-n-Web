# Guía para el examen: diseño y construcción de la API

Esta guía está pensada para el momento del examen: te dan un **tema**
(ej. "tienda de zapatos", "biblioteca", "empleados", "vehículos") y un
**tiempo limitado**. El objetivo es que sigas estos pasos en orden y
adaptes la plantilla sin tener que pensar la estructura desde cero.

---

## Paso 1 — Diseñar las URIs (antes de programar)

Antes de tocar código, dibuja una tabla como esta en un papel/editor.
Esto es exactamente lo que normalmente te pedirán entregar primero.

### 1.1 Tabla de referencia general (CRUD)

Supongamos que tu entidad se llama `<recurso>` (ej. `products`, `books`,
`employees`...). El patrón CRUD es **siempre el mismo**:

| Operación | Método | URI | Request Body | Response Body | HTTP éxito | HTTP error |
|---|---|---|---|---|---|---|
| Crear | `POST` | `/api/<recurso>` | JSON con los campos del nuevo registro | objeto creado (con `id`) | `201 Created` | `400 Bad Request` (validación) |
| Listar todos | `GET` | `/api/<recurso>` | — (sin body) | arreglo de objetos | `200 OK` | `500 Internal Server Error` |
| Obtener uno | `GET` | `/api/<recurso>/:id` | — | objeto | `200 OK` | `404 Not Found` |
| Actualizar | `PUT` | `/api/<recurso>/:id` | JSON con TODOS los campos editables | objeto actualizado | `200 OK` | `404 Not Found`, `400 Bad Request` |
| Eliminar | `DELETE` | `/api/<recurso>/:id` | — | mensaje de confirmación | `200 OK` (o `204 No Content`) | `404 Not Found` |

### 1.2 Tabla de referencia general (Reglas de negocio / cálculos)

Casi cualquier "regla de negocio" del examen se reduce a una de estas
dos formas:

| Tipo de regla | Método | URI | Request Body | Response Body | HTTP éxito | HTTP error |
|---|---|---|---|---|---|---|
| Cálculo sobre **un solo registro** | `GET` | `/api/<recurso>/:id/<calculo>` | — | objeto con el resultado calculado | `200 OK` | `404 Not Found` |
| Cálculo/orden sobre **toda la lista** | `GET` | `/api/<recurso>/<calculo>` | — | arreglo ordenado/resumido | `200 OK` | `500 Internal Server Error` |

Ejemplos reales que ya viste:

- `GET /api/students/:id/average` → promedio de un alumno (individual).
- `GET /api/students/ranking` → ranking de todos los alumnos (lista).
- `GET /api/movies/:id/revenue` → ingresos de una película (individual).
- `GET /api/movies/ranking` → ranking de rentabilidad (lista).

> **Regla de oro:** toda URI con texto fijo (`ranking`, `average`,
> `revenue`, `report`, etc.) debe declararse **antes** que `/:id` en el
> archivo de rutas. Si no, Express interpreta ese texto como un `id`.

---

## Paso 2 — Entender los métodos HTTP (semántica)

| Método | Significado | ¿Modifica datos? | ¿Tiene body? | Idempotente* |
|---|---|---|---|---|
| `GET` | Leer / consultar | No | No | Sí |
| `POST` | Crear un nuevo recurso | Sí (inserta) | Sí | No |
| `PUT` | Reemplazar un recurso existente por completo | Sí (actualiza) | Sí (todos los campos) | Sí |
| `DELETE` | Eliminar un recurso | Sí (borra) | No | Sí |

\* *Idempotente* = ejecutarlo varias veces produce el mismo resultado
que ejecutarlo una vez (ej. `DELETE /api/students/5` da el mismo estado
final aunque lo llames 1 o 10 veces; en cambio cada `POST` crea un
registro nuevo).

**Notas importantes para el examen:**

- `PUT` espera **todos** los campos del objeto (reemplazo completo). Si
  el examen pide actualizar solo *algunos* campos, eso es `PATCH`
  (no incluido en esta plantilla, pero el patrón es casi igual a `PUT`
  salvo que cada campo es opcional en la validación).
- `DELETE` normalmente no lleva body ni en la petición ni
  necesariamente en la respuesta. Esta plantilla responde `200` con un
  mensaje; si el examen exige `204 No Content`, cambia esa línea a
  `res.status(204).send();`.

---

## Paso 3 — Códigos HTTP que vas a usar

| Código | Nombre | Cuándo se usa |
|---|---|---|
| `200 OK` | Éxito | GET, PUT y DELETE exitosos |
| `201 Created` | Creado | POST exitoso (se creó un nuevo registro) |
| `204 No Content` | Sin contenido | Alternativa para DELETE exitoso (sin body) |
| `400 Bad Request` | Solicitud inválida | Faltan campos o tienen formato/valor incorrecto |
| `404 Not Found` | No encontrado | El `:id` no existe en la base de datos |
| `500 Internal Server Error` | Error del servidor | Falla de conexión a BD o error inesperado (try/catch) |

---

## Paso 4 — Identificar las reglas de negocio (cálculos)

En el examen, una "regla de negocio con cálculo" casi siempre es una de
estas categorías:

1. **Cálculo aritmético simple sobre los campos de un registro.**
   Ejemplos: promedio de notas, IMC (peso/estatura²), total de una
   factura (cantidad × precio), interés de un préstamo, edad a partir
   de fecha de nacimiento.

   → Se implementa como `calculateX(entity)`, función pura que recibe
   el objeto y retorna un número. Se usa en el endpoint
   `GET /:id/<calculo>`.

2. **Operación sobre toda la colección: ranking, filtrado o resumen.**
   Ejemplos: top 5 más vendidos, promedio general de la clase,
   estudiantes que aprobaron/reprobaron, total de inventario.

   → Se implementa como `buildX(entities)`: recorre el arreglo,
   reutiliza `calculateX` para cada elemento, y luego
   ordena/filtra/agrupa. Se usa en `GET /<calculo>`.

**Importante:** estos valores **NUNCA se guardan en la base de datos**.
Se calculan "al vuelo" (en memoria, con JavaScript) cada vez que se
solicita el endpoint. Esto es porque:
- Evita inconsistencias (si se actualiza una nota, el promedio
  "guardado" quedaría desactualizado).
- El examen casi siempre lo pide explícitamente ("no debe almacenarse",
  "debe calcularse dinámicamente").

---

## Paso 5 — Adaptar la plantilla a tu tema (checklist)

Supongamos que el tema del examen es **"tienda de zapatos"**, entidad
`products`, con regla de negocio "calcular el descuento aplicado y el
precio final" + "listar productos ordenados por precio final".

### 5.1 Diseña primero la tabla de URIs (Paso 1) con tu entidad

| Operación | Método | URI |
|---|---|---|
| Crear producto | POST | `/api/products` |
| Listar productos | GET | `/api/products` |
| Obtener producto | GET | `/api/products/:id` |
| Actualizar producto | PUT | `/api/products/:id` |
| Eliminar producto | DELETE | `/api/products/:id` |
| Precio final de un producto (regla 1) | GET | `/api/products/:id/final-price` |
| Listado ordenado por precio final (regla 2) | GET | `/api/products/cheapest` |

### 5.2 Archivos a modificar (en este orden)

1. **`sql/01_create_tables.sql`**
   - Cambia `CREATE TABLE students` → `CREATE TABLE products`.
   - Cambia las columnas: `name`, `price`, `discount_percentage`, etc.
   - Agrega los `CHECK` que pida el examen (ej. `price > 0`,
     `discount_percentage BETWEEN 0 AND 100`).

2. **`sql/02_seed_data.sql`**
   - Cambia los `INSERT INTO students` → `INSERT INTO products` con
     datos de ejemplo coherentes con tu entidad.

3. **`models/student.js` → renómbralo a `models/product.js`**
   - Cambia el nombre de la tabla en cada query (`'students'` →
     `'products'`).
   - En `toStudent` (renómbralo `toProduct`), ajusta el mapeo de
     columnas `snake_case` → `camelCase` según tus nuevas columnas.
   - Ajusta los parámetros de `create` y `update` a los nuevos campos.
   - **No cambies la forma de las 5 funciones** (`findAll`, `findById`,
     `create`, `update`, `remove`): así no tienes que rediseñar las rutas.

4. **`routes/studentRoutes.js` → renómbralo a `routes/productRoutes.js`**
   - Cambia `require('../models/student')` → `require('../models/product')`.
   - Reescribe `validateStudentBody` → `validateProductBody` con las
     reglas que pida el examen (obligatorio, numérico, rangos).
   - Reescribe las funciones de cálculo:
     - `calculateAverage` → `calculateFinalPrice` (ej.
       `price - (price * discountPercentage / 100)`).
     - `buildRanking` → `buildCheapestList` (mismo patrón: map + sort +
       map con índice).
   - Cambia las URIs de los endpoints de cálculo:
     - `/:id/average` → `/:id/final-price`
     - `/ranking` → `/cheapest`
   - **Recuerda el orden**: las rutas con texto fijo (`/cheapest`,
     `/:id/final-price`) van antes de `/:id`.

5. **`index.js`**
   - Cambia:
     ```js
     const studentRouter = require('./routes/studentRoutes');
     app.use('/api/students', studentRouter);
     ```
     por:
     ```js
     const productRouter = require('./routes/productRoutes');
     app.use('/api/products', productRouter);
     ```

6. **`.env`** — normalmente no cambia (mismas credenciales de Supabase),
   solo asegúrate de correr los nuevos scripts SQL en el proyecto correcto.

### 5.3 Orden de trabajo recomendado durante el examen

1. Diseña la tabla de URIs (Paso 1) — 5 min.
2. Escribe el SQL (`01_create_tables.sql`, `02_seed_data.sql`) y
   ejecútalo en Supabase — 10 min.
3. Adapta el modelo (`models/`) — 10 min.
4. Adapta las rutas: primero CRUD, luego las reglas de negocio —
   15-20 min.
5. Actualiza `index.js` — 1 min.
6. Prueba con Postman/Thunder Client, en este orden:
   `POST` → `GET all` → `GET :id` → regla de negocio individual →
   regla de negocio de lista → `PUT` → `DELETE`.

---

## Resumen mental rápido

- **CRUD = 5 endpoints fijos**, siempre el mismo patrón (tabla del Paso 1.1).
- **Regla de negocio = función pura de cálculo** + 1 endpoint que la usa
  (individual o sobre toda la lista).
- **Las rutas de texto fijo van antes que `/:id`.**
- **Nunca guardes en la BD lo que se puede calcular.**
- **Valida antes de tocar la base de datos**; si hay errores, `400` y
  no llames al modelo.
- **`id` no encontrado → siempre `404`**, tanto en GET, PUT como DELETE.
