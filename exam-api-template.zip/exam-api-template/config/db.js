const { Pool } = require('pg');

// ─────────────────────────────────────────────────────────────────────────
// GUÍA: Este archivo NO cambia entre proyectos. Es genérico para cualquier
// tema de examen. Solo asegúrate de que las variables de entorno del .env
// coincidan con tu instancia de Supabase.
// ─────────────────────────────────────────────────────────────────────────

const pool = new Pool({
    host:     process.env.DB_HOST,
    port:     process.env.DB_PORT     || 5432,
    database: process.env.DB_NAME,
    user:     process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    ssl: {
        rejectUnauthorized: false
    }
});

pool.on('connect', () => {
    console.log('Connected to Supabase PostgreSQL database');
});

pool.on('error', (err) => {
    console.error('Unexpected database error:', err);
    process.exit(-1);
});

module.exports = pool;
