<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Index</title>
</head>

<body>
<?php
	header("Location:paginas/login.html");
?>
	
</body>
</html>